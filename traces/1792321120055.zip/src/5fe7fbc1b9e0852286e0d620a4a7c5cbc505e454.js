"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const node_util_1 = __importDefault(require("node:util"));
const time_1 = require("./time");
const uncaught_exception_manager_1 = __importDefault(require("./uncaught_exception_manager"));
const value_checker_1 = require("./value_checker");
const UserCodeRunner = {
    async run({ argsArray, thisArg, fn, timeoutInMilliseconds }) {
        const callbackPromise = new Promise((resolve, reject) => {
            argsArray.push((error, result) => {
                if ((0, value_checker_1.doesHaveValue)(error)) {
                    reject(error);
                }
                else {
                    resolve(result);
                }
            });
        });
        let fnReturn;
        try {
            fnReturn = fn.apply(thisArg, argsArray);
        }
        catch (e) {
            const error = e instanceof Error ? e : node_util_1.default.format(e);
            return { error };
        }
        const racingPromises = [];
        const callbackInterface = fn.length === argsArray.length;
        const promiseInterface = (0, value_checker_1.doesHaveValue)(fnReturn) && typeof fnReturn.then === 'function';
        if (callbackInterface && promiseInterface) {
            return {
                error: new Error('function uses multiple asynchronous interfaces: callback and promise\n' +
                    'to use the callback interface: do not return a promise\n' +
                    'to use the promise interface: remove the last argument to the function'),
            };
        }
        else if (callbackInterface) {
            racingPromises.push(callbackPromise);
        }
        else if (promiseInterface) {
            racingPromises.push(fnReturn);
        }
        else {
            return { result: fnReturn };
        }
        let exceptionHandler;
        const uncaughtExceptionPromise = new Promise((_resolve, reject) => {
            exceptionHandler = reject;
            uncaught_exception_manager_1.default.registerHandler(exceptionHandler);
        });
        racingPromises.push(uncaughtExceptionPromise);
        let finalPromise = Promise.race(racingPromises);
        if (timeoutInMilliseconds >= 0) {
            const timeoutMessage = 'function timed out, ensure the ' +
                (callbackInterface ? 'callback is executed' : 'promise resolves') +
                ` within ${timeoutInMilliseconds.toString()} milliseconds`;
            finalPromise = (0, time_1.wrapPromiseWithTimeout)(finalPromise, timeoutInMilliseconds, timeoutMessage);
        }
        let error, result;
        try {
            result = await finalPromise;
        }
        catch (e) {
            if (e instanceof Error) {
                error = e;
            }
            else if ((0, value_checker_1.doesHaveValue)(e)) {
                error = node_util_1.default.format(e);
            }
            else {
                error = new Error('Promise rejected without a reason');
            }
        }
        uncaught_exception_manager_1.default.unregisterHandler(exceptionHandler);
        return { error, result };
    },
};
exports.default = UserCodeRunner;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlcl9jb2RlX3J1bm5lci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy91c2VyX2NvZGVfcnVubmVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7O0FBQUEsMERBQTRCO0FBQzVCLGlDQUErQztBQUMvQyw4RkFBbUU7QUFDbkUsbURBQStDO0FBYy9DLE1BQU0sY0FBYyxHQUFHO0lBQ3JCLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxxQkFBcUIsRUFBZTtRQUN0RSxNQUFNLGVBQWUsR0FBRyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsRUFBRTtZQUN0RCxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBWSxFQUFFLE1BQW9CLEVBQUUsRUFBRTtnQkFDcEQsSUFBSSxJQUFBLDZCQUFhLEVBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDekIsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFBO2dCQUNmLENBQUM7cUJBQU0sQ0FBQztvQkFDTixPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7Z0JBQ2pCLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUMsQ0FBQyxDQUFBO1FBRUYsSUFBSSxRQUFhLENBQUE7UUFDakIsSUFBSSxDQUFDO1lBQ0gsUUFBUSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFBO1FBQ3pDLENBQUM7UUFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ1gsTUFBTSxLQUFLLEdBQUcsQ0FBQyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNyRCxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUE7UUFDbEIsQ0FBQztRQUVELE1BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQTtRQUN6QixNQUFNLGlCQUFpQixHQUFHLEVBQUUsQ0FBQyxNQUFNLEtBQUssU0FBUyxDQUFDLE1BQU0sQ0FBQTtRQUN4RCxNQUFNLGdCQUFnQixHQUFHLElBQUEsNkJBQWEsRUFBQyxRQUFRLENBQUMsSUFBSSxPQUFPLFFBQVEsQ0FBQyxJQUFJLEtBQUssVUFBVSxDQUFBO1FBRXZGLElBQUksaUJBQWlCLElBQUksZ0JBQWdCLEVBQUUsQ0FBQztZQUMxQyxPQUFPO2dCQUNMLEtBQUssRUFBRSxJQUFJLEtBQUssQ0FDZCx3RUFBd0U7b0JBQ3RFLDBEQUEwRDtvQkFDMUQsd0VBQXdFLENBQzNFO2FBQ0YsQ0FBQTtRQUNILENBQUM7YUFBTSxJQUFJLGlCQUFpQixFQUFFLENBQUM7WUFDN0IsY0FBYyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQTtRQUN0QyxDQUFDO2FBQU0sSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1lBQzVCLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDL0IsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxDQUFBO1FBQzdCLENBQUM7UUFFRCxJQUFJLGdCQUFxQixDQUFBO1FBQ3pCLE1BQU0sd0JBQXdCLEdBQUcsSUFBSSxPQUFPLENBQUMsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDaEUsZ0JBQWdCLEdBQUcsTUFBTSxDQUFBO1lBQ3pCLG9DQUF3QixDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO1FBQzVELENBQUMsQ0FBQyxDQUFBO1FBQ0YsY0FBYyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO1FBRTdDLElBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUE7UUFDL0MsSUFBSSxxQkFBcUIsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUMvQixNQUFNLGNBQWMsR0FDbEIsaUNBQWlDO2dCQUNqQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7Z0JBQ2pFLFdBQVcscUJBQXFCLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQTtZQUM1RCxZQUFZLEdBQUcsSUFBQSw2QkFBc0IsRUFBQyxZQUFZLEVBQUUscUJBQXFCLEVBQUUsY0FBYyxDQUFDLENBQUE7UUFDNUYsQ0FBQztRQUVELElBQUksS0FBVSxFQUFFLE1BQVcsQ0FBQTtRQUMzQixJQUFJLENBQUM7WUFDSCxNQUFNLEdBQUcsTUFBTSxZQUFZLENBQUE7UUFDN0IsQ0FBQztRQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDWCxJQUFJLENBQUMsWUFBWSxLQUFLLEVBQUUsQ0FBQztnQkFDdkIsS0FBSyxHQUFHLENBQUMsQ0FBQTtZQUNYLENBQUM7aUJBQU0sSUFBSSxJQUFBLDZCQUFhLEVBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDNUIsS0FBSyxHQUFHLG1CQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQ3hCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixLQUFLLEdBQUcsSUFBSSxLQUFLLENBQUMsbUNBQW1DLENBQUMsQ0FBQTtZQUN4RCxDQUFDO1FBQ0gsQ0FBQztRQUVELG9DQUF3QixDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLENBQUE7UUFFNUQsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQTtJQUMxQixDQUFDO0NBQ0YsQ0FBQTtBQUVELGtCQUFlLGNBQWMsQ0FBQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB1dGlsIGZyb20gJ25vZGU6dXRpbCdcbmltcG9ydCB7IHdyYXBQcm9taXNlV2l0aFRpbWVvdXQgfSBmcm9tICcuL3RpbWUnXG5pbXBvcnQgVW5jYXVnaHRFeGNlcHRpb25NYW5hZ2VyIGZyb20gJy4vdW5jYXVnaHRfZXhjZXB0aW9uX21hbmFnZXInXG5pbXBvcnQgeyBkb2VzSGF2ZVZhbHVlIH0gZnJvbSAnLi92YWx1ZV9jaGVja2VyJ1xuXG5leHBvcnQgaW50ZXJmYWNlIElSdW5SZXF1ZXN0IHtcbiAgYXJnc0FycmF5OiBhbnlbXVxuICB0aGlzQXJnOiBhbnlcbiAgZm46IEZ1bmN0aW9uXG4gIHRpbWVvdXRJbk1pbGxpc2Vjb25kczogbnVtYmVyXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVJ1blJlc3BvbnNlIHtcbiAgZXJyb3I/OiBhbnlcbiAgcmVzdWx0PzogYW55XG59XG5cbmNvbnN0IFVzZXJDb2RlUnVubmVyID0ge1xuICBhc3luYyBydW4oeyBhcmdzQXJyYXksIHRoaXNBcmcsIGZuLCB0aW1lb3V0SW5NaWxsaXNlY29uZHMgfTogSVJ1blJlcXVlc3QpOiBQcm9taXNlPElSdW5SZXNwb25zZT4ge1xuICAgIGNvbnN0IGNhbGxiYWNrUHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGFyZ3NBcnJheS5wdXNoKChlcnJvcjogRXJyb3IsIHJlc3VsdDogSVJ1blJlc3BvbnNlKSA9PiB7XG4gICAgICAgIGlmIChkb2VzSGF2ZVZhbHVlKGVycm9yKSkge1xuICAgICAgICAgIHJlamVjdChlcnJvcilcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXNvbHZlKHJlc3VsdClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9KVxuXG4gICAgbGV0IGZuUmV0dXJuOiBhbnlcbiAgICB0cnkge1xuICAgICAgZm5SZXR1cm4gPSBmbi5hcHBseSh0aGlzQXJnLCBhcmdzQXJyYXkpXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc3QgZXJyb3IgPSBlIGluc3RhbmNlb2YgRXJyb3IgPyBlIDogdXRpbC5mb3JtYXQoZSlcbiAgICAgIHJldHVybiB7IGVycm9yIH1cbiAgICB9XG5cbiAgICBjb25zdCByYWNpbmdQcm9taXNlcyA9IFtdXG4gICAgY29uc3QgY2FsbGJhY2tJbnRlcmZhY2UgPSBmbi5sZW5ndGggPT09IGFyZ3NBcnJheS5sZW5ndGhcbiAgICBjb25zdCBwcm9taXNlSW50ZXJmYWNlID0gZG9lc0hhdmVWYWx1ZShmblJldHVybikgJiYgdHlwZW9mIGZuUmV0dXJuLnRoZW4gPT09ICdmdW5jdGlvbidcblxuICAgIGlmIChjYWxsYmFja0ludGVyZmFjZSAmJiBwcm9taXNlSW50ZXJmYWNlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBlcnJvcjogbmV3IEVycm9yKFxuICAgICAgICAgICdmdW5jdGlvbiB1c2VzIG11bHRpcGxlIGFzeW5jaHJvbm91cyBpbnRlcmZhY2VzOiBjYWxsYmFjayBhbmQgcHJvbWlzZVxcbicgK1xuICAgICAgICAgICAgJ3RvIHVzZSB0aGUgY2FsbGJhY2sgaW50ZXJmYWNlOiBkbyBub3QgcmV0dXJuIGEgcHJvbWlzZVxcbicgK1xuICAgICAgICAgICAgJ3RvIHVzZSB0aGUgcHJvbWlzZSBpbnRlcmZhY2U6IHJlbW92ZSB0aGUgbGFzdCBhcmd1bWVudCB0byB0aGUgZnVuY3Rpb24nXG4gICAgICAgICksXG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChjYWxsYmFja0ludGVyZmFjZSkge1xuICAgICAgcmFjaW5nUHJvbWlzZXMucHVzaChjYWxsYmFja1Byb21pc2UpXG4gICAgfSBlbHNlIGlmIChwcm9taXNlSW50ZXJmYWNlKSB7XG4gICAgICByYWNpbmdQcm9taXNlcy5wdXNoKGZuUmV0dXJuKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4geyByZXN1bHQ6IGZuUmV0dXJuIH1cbiAgICB9XG5cbiAgICBsZXQgZXhjZXB0aW9uSGFuZGxlcjogYW55XG4gICAgY29uc3QgdW5jYXVnaHRFeGNlcHRpb25Qcm9taXNlID0gbmV3IFByb21pc2UoKF9yZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGV4Y2VwdGlvbkhhbmRsZXIgPSByZWplY3RcbiAgICAgIFVuY2F1Z2h0RXhjZXB0aW9uTWFuYWdlci5yZWdpc3RlckhhbmRsZXIoZXhjZXB0aW9uSGFuZGxlcilcbiAgICB9KVxuICAgIHJhY2luZ1Byb21pc2VzLnB1c2godW5jYXVnaHRFeGNlcHRpb25Qcm9taXNlKVxuXG4gICAgbGV0IGZpbmFsUHJvbWlzZSA9IFByb21pc2UucmFjZShyYWNpbmdQcm9taXNlcylcbiAgICBpZiAodGltZW91dEluTWlsbGlzZWNvbmRzID49IDApIHtcbiAgICAgIGNvbnN0IHRpbWVvdXRNZXNzYWdlID1cbiAgICAgICAgJ2Z1bmN0aW9uIHRpbWVkIG91dCwgZW5zdXJlIHRoZSAnICtcbiAgICAgICAgKGNhbGxiYWNrSW50ZXJmYWNlID8gJ2NhbGxiYWNrIGlzIGV4ZWN1dGVkJyA6ICdwcm9taXNlIHJlc29sdmVzJykgK1xuICAgICAgICBgIHdpdGhpbiAke3RpbWVvdXRJbk1pbGxpc2Vjb25kcy50b1N0cmluZygpfSBtaWxsaXNlY29uZHNgXG4gICAgICBmaW5hbFByb21pc2UgPSB3cmFwUHJvbWlzZVdpdGhUaW1lb3V0KGZpbmFsUHJvbWlzZSwgdGltZW91dEluTWlsbGlzZWNvbmRzLCB0aW1lb3V0TWVzc2FnZSlcbiAgICB9XG5cbiAgICBsZXQgZXJyb3I6IGFueSwgcmVzdWx0OiBhbnlcbiAgICB0cnkge1xuICAgICAgcmVzdWx0ID0gYXdhaXQgZmluYWxQcm9taXNlXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICBlcnJvciA9IGVcbiAgICAgIH0gZWxzZSBpZiAoZG9lc0hhdmVWYWx1ZShlKSkge1xuICAgICAgICBlcnJvciA9IHV0aWwuZm9ybWF0KGUpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlcnJvciA9IG5ldyBFcnJvcignUHJvbWlzZSByZWplY3RlZCB3aXRob3V0IGEgcmVhc29uJylcbiAgICAgIH1cbiAgICB9XG5cbiAgICBVbmNhdWdodEV4Y2VwdGlvbk1hbmFnZXIudW5yZWdpc3RlckhhbmRsZXIoZXhjZXB0aW9uSGFuZGxlcilcblxuICAgIHJldHVybiB7IGVycm9yLCByZXN1bHQgfVxuICB9LFxufVxuXG5leHBvcnQgZGVmYXVsdCBVc2VyQ29kZVJ1bm5lclxuIl19