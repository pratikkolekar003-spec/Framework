"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.run = run;
const messages_1 = require("@cucumber/messages");
const user_code_runner_1 = __importDefault(require("../user_code_runner"));
const value_checker_1 = require("../value_checker");
const format_error_1 = require("./format_error");
const scope_1 = require("./scope");
const stopwatch_1 = require("./stopwatch");
async function run({ defaultTimeout, filterStackTraces, hookParameter, step, stepDefinition, world, }) {
    const stopwatch = (0, stopwatch_1.create)().start();
    let error, result, invocationData;
    try {
        await (0, scope_1.runInTestCaseScope)({ world }, async () => {
            invocationData = await stepDefinition.getInvocationParameters({
                hookParameter,
                step,
                world,
            });
        });
    }
    catch (err) {
        error = err;
    }
    if ((0, value_checker_1.doesNotHaveValue)(error)) {
        const timeoutInMilliseconds = (0, value_checker_1.valueOrDefault)(stepDefinition.options.timeout, defaultTimeout);
        if (invocationData.validCodeLengths.includes(stepDefinition.code.length)) {
            const data = await (0, scope_1.runInTestCaseScope)({ world }, async () => user_code_runner_1.default.run({
                argsArray: invocationData.parameters,
                fn: stepDefinition.code,
                thisArg: world,
                timeoutInMilliseconds,
            }));
            error = data.error;
            result = data.result;
        }
        else {
            error = invocationData.getInvalidCodeLengthMessage();
        }
    }
    const duration = stopwatch.stop().duration();
    let status;
    let details = {};
    if (result === 'skipped') {
        status = messages_1.TestStepResultStatus.SKIPPED;
    }
    else if (result === 'pending') {
        status = messages_1.TestStepResultStatus.PENDING;
    }
    else if ((0, value_checker_1.doesHaveValue)(error)) {
        status = messages_1.TestStepResultStatus.FAILED;
    }
    else {
        status = messages_1.TestStepResultStatus.PASSED;
    }
    if ((0, value_checker_1.doesHaveValue)(error)) {
        details = (0, format_error_1.formatError)(error, filterStackTraces);
    }
    return {
        result: {
            duration,
            status,
            ...details,
        },
        error,
    };
}
exports.default = { run };
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcF9ydW5uZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvcnVudGltZS9zdGVwX3J1bm5lci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQXVCQSxrQkFtRUM7QUExRkQsaURBQStGO0FBRy9GLDJFQUFnRDtBQUNoRCxvREFBa0Y7QUFDbEYsaURBQTRDO0FBQzVDLG1DQUE0QztBQUM1QywyQ0FBb0M7QUFnQjdCLEtBQUssVUFBVSxHQUFHLENBQUMsRUFDeEIsY0FBYyxFQUNkLGlCQUFpQixFQUNqQixhQUFhLEVBQ2IsSUFBSSxFQUNKLGNBQWMsRUFDZCxLQUFLLEdBQ087SUFDWixNQUFNLFNBQVMsR0FBRyxJQUFBLGtCQUFNLEdBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUNsQyxJQUFJLEtBQVUsRUFBRSxNQUFXLEVBQUUsY0FBMEMsQ0FBQTtJQUV2RSxJQUFJLENBQUM7UUFDSCxNQUFNLElBQUEsMEJBQWtCLEVBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxLQUFLLElBQUksRUFBRTtZQUM3QyxjQUFjLEdBQUcsTUFBTSxjQUFjLENBQUMsdUJBQXVCLENBQUM7Z0JBQzVELGFBQWE7Z0JBQ2IsSUFBSTtnQkFDSixLQUFLO2FBQ04sQ0FBQyxDQUFBO1FBQ0osQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUNiLEtBQUssR0FBRyxHQUFHLENBQUE7SUFDYixDQUFDO0lBRUQsSUFBSSxJQUFBLGdDQUFnQixFQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDNUIsTUFBTSxxQkFBcUIsR0FBRyxJQUFBLDhCQUFjLEVBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDLENBQUE7UUFFNUYsSUFBSSxjQUFjLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztZQUN6RSxNQUFNLElBQUksR0FBRyxNQUFNLElBQUEsMEJBQWtCLEVBQUMsRUFBRSxLQUFLLEVBQUUsRUFBRSxLQUFLLElBQUksRUFBRSxDQUMxRCwwQkFBYyxDQUFDLEdBQUcsQ0FBQztnQkFDakIsU0FBUyxFQUFFLGNBQWMsQ0FBQyxVQUFVO2dCQUNwQyxFQUFFLEVBQUUsY0FBYyxDQUFDLElBQUk7Z0JBQ3ZCLE9BQU8sRUFBRSxLQUFLO2dCQUNkLHFCQUFxQjthQUN0QixDQUFDLENBQ0gsQ0FBQTtZQUNELEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFBO1lBQ2xCLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFBO1FBQ3RCLENBQUM7YUFBTSxDQUFDO1lBQ04sS0FBSyxHQUFHLGNBQWMsQ0FBQywyQkFBMkIsRUFBRSxDQUFBO1FBQ3RELENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTSxRQUFRLEdBQUcsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFBO0lBQzVDLElBQUksTUFBNEIsQ0FBQTtJQUNoQyxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUE7SUFDaEIsSUFBSSxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDekIsTUFBTSxHQUFHLCtCQUFvQixDQUFDLE9BQU8sQ0FBQTtJQUN2QyxDQUFDO1NBQU0sSUFBSSxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDaEMsTUFBTSxHQUFHLCtCQUFvQixDQUFDLE9BQU8sQ0FBQTtJQUN2QyxDQUFDO1NBQU0sSUFBSSxJQUFBLDZCQUFhLEVBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUNoQyxNQUFNLEdBQUcsK0JBQW9CLENBQUMsTUFBTSxDQUFBO0lBQ3RDLENBQUM7U0FBTSxDQUFDO1FBQ04sTUFBTSxHQUFHLCtCQUFvQixDQUFDLE1BQU0sQ0FBQTtJQUN0QyxDQUFDO0lBRUQsSUFBSSxJQUFBLDZCQUFhLEVBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztRQUN6QixPQUFPLEdBQUcsSUFBQSwwQkFBVyxFQUFDLEtBQUssRUFBRSxpQkFBaUIsQ0FBQyxDQUFBO0lBQ2pELENBQUM7SUFFRCxPQUFPO1FBQ0wsTUFBTSxFQUFFO1lBQ04sUUFBUTtZQUNSLE1BQU07WUFDTixHQUFHLE9BQU87U0FDWDtRQUNELEtBQUs7S0FDTixDQUFBO0FBQ0gsQ0FBQztBQUVELGtCQUFlLEVBQUUsR0FBRyxFQUFFLENBQUEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0eXBlIFBpY2tsZVN0ZXAsIHR5cGUgVGVzdFN0ZXBSZXN1bHQsIFRlc3RTdGVwUmVzdWx0U3RhdHVzIH0gZnJvbSAnQGN1Y3VtYmVyL21lc3NhZ2VzJ1xuaW1wb3J0IHR5cGUgeyBJRGVmaW5pdGlvbiwgSUdldEludm9jYXRpb25EYXRhUmVzcG9uc2UgfSBmcm9tICcuLi9tb2RlbHMvZGVmaW5pdGlvbidcbmltcG9ydCB0eXBlIHsgSVRlc3RDYXNlSG9va1BhcmFtZXRlciB9IGZyb20gJy4uL3N1cHBvcnRfY29kZV9saWJyYXJ5X2J1aWxkZXIvdHlwZXMnXG5pbXBvcnQgVXNlckNvZGVSdW5uZXIgZnJvbSAnLi4vdXNlcl9jb2RlX3J1bm5lcidcbmltcG9ydCB7IGRvZXNIYXZlVmFsdWUsIGRvZXNOb3RIYXZlVmFsdWUsIHZhbHVlT3JEZWZhdWx0IH0gZnJvbSAnLi4vdmFsdWVfY2hlY2tlcidcbmltcG9ydCB7IGZvcm1hdEVycm9yIH0gZnJvbSAnLi9mb3JtYXRfZXJyb3InXG5pbXBvcnQgeyBydW5JblRlc3RDYXNlU2NvcGUgfSBmcm9tICcuL3Njb3BlJ1xuaW1wb3J0IHsgY3JlYXRlIH0gZnJvbSAnLi9zdG9wd2F0Y2gnXG5cbmV4cG9ydCBpbnRlcmZhY2UgSVJ1bk9wdGlvbnMge1xuICBkZWZhdWx0VGltZW91dDogbnVtYmVyXG4gIGZpbHRlclN0YWNrVHJhY2VzOiBib29sZWFuXG4gIGhvb2tQYXJhbWV0ZXI6IElUZXN0Q2FzZUhvb2tQYXJhbWV0ZXJcbiAgc3RlcDogUGlja2xlU3RlcFxuICBzdGVwRGVmaW5pdGlvbjogSURlZmluaXRpb25cbiAgd29ybGQ6IGFueVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJ1blN0ZXBSZXN1bHQge1xuICByZXN1bHQ6IFRlc3RTdGVwUmVzdWx0XG4gIGVycm9yPzogYW55XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBydW4oe1xuICBkZWZhdWx0VGltZW91dCxcbiAgZmlsdGVyU3RhY2tUcmFjZXMsXG4gIGhvb2tQYXJhbWV0ZXIsXG4gIHN0ZXAsXG4gIHN0ZXBEZWZpbml0aW9uLFxuICB3b3JsZCxcbn06IElSdW5PcHRpb25zKTogUHJvbWlzZTxSdW5TdGVwUmVzdWx0PiB7XG4gIGNvbnN0IHN0b3B3YXRjaCA9IGNyZWF0ZSgpLnN0YXJ0KClcbiAgbGV0IGVycm9yOiBhbnksIHJlc3VsdDogYW55LCBpbnZvY2F0aW9uRGF0YTogSUdldEludm9jYXRpb25EYXRhUmVzcG9uc2VcblxuICB0cnkge1xuICAgIGF3YWl0IHJ1bkluVGVzdENhc2VTY29wZSh7IHdvcmxkIH0sIGFzeW5jICgpID0+IHtcbiAgICAgIGludm9jYXRpb25EYXRhID0gYXdhaXQgc3RlcERlZmluaXRpb24uZ2V0SW52b2NhdGlvblBhcmFtZXRlcnMoe1xuICAgICAgICBob29rUGFyYW1ldGVyLFxuICAgICAgICBzdGVwLFxuICAgICAgICB3b3JsZCxcbiAgICAgIH0pXG4gICAgfSlcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgZXJyb3IgPSBlcnJcbiAgfVxuXG4gIGlmIChkb2VzTm90SGF2ZVZhbHVlKGVycm9yKSkge1xuICAgIGNvbnN0IHRpbWVvdXRJbk1pbGxpc2Vjb25kcyA9IHZhbHVlT3JEZWZhdWx0KHN0ZXBEZWZpbml0aW9uLm9wdGlvbnMudGltZW91dCwgZGVmYXVsdFRpbWVvdXQpXG5cbiAgICBpZiAoaW52b2NhdGlvbkRhdGEudmFsaWRDb2RlTGVuZ3Rocy5pbmNsdWRlcyhzdGVwRGVmaW5pdGlvbi5jb2RlLmxlbmd0aCkpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBydW5JblRlc3RDYXNlU2NvcGUoeyB3b3JsZCB9LCBhc3luYyAoKSA9PlxuICAgICAgICBVc2VyQ29kZVJ1bm5lci5ydW4oe1xuICAgICAgICAgIGFyZ3NBcnJheTogaW52b2NhdGlvbkRhdGEucGFyYW1ldGVycyxcbiAgICAgICAgICBmbjogc3RlcERlZmluaXRpb24uY29kZSxcbiAgICAgICAgICB0aGlzQXJnOiB3b3JsZCxcbiAgICAgICAgICB0aW1lb3V0SW5NaWxsaXNlY29uZHMsXG4gICAgICAgIH0pXG4gICAgICApXG4gICAgICBlcnJvciA9IGRhdGEuZXJyb3JcbiAgICAgIHJlc3VsdCA9IGRhdGEucmVzdWx0XG4gICAgfSBlbHNlIHtcbiAgICAgIGVycm9yID0gaW52b2NhdGlvbkRhdGEuZ2V0SW52YWxpZENvZGVMZW5ndGhNZXNzYWdlKClcbiAgICB9XG4gIH1cblxuICBjb25zdCBkdXJhdGlvbiA9IHN0b3B3YXRjaC5zdG9wKCkuZHVyYXRpb24oKVxuICBsZXQgc3RhdHVzOiBUZXN0U3RlcFJlc3VsdFN0YXR1c1xuICBsZXQgZGV0YWlscyA9IHt9XG4gIGlmIChyZXN1bHQgPT09ICdza2lwcGVkJykge1xuICAgIHN0YXR1cyA9IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlNLSVBQRURcbiAgfSBlbHNlIGlmIChyZXN1bHQgPT09ICdwZW5kaW5nJykge1xuICAgIHN0YXR1cyA9IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlBFTkRJTkdcbiAgfSBlbHNlIGlmIChkb2VzSGF2ZVZhbHVlKGVycm9yKSkge1xuICAgIHN0YXR1cyA9IFRlc3RTdGVwUmVzdWx0U3RhdHVzLkZBSUxFRFxuICB9IGVsc2Uge1xuICAgIHN0YXR1cyA9IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlBBU1NFRFxuICB9XG5cbiAgaWYgKGRvZXNIYXZlVmFsdWUoZXJyb3IpKSB7XG4gICAgZGV0YWlscyA9IGZvcm1hdEVycm9yKGVycm9yLCBmaWx0ZXJTdGFja1RyYWNlcylcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgcmVzdWx0OiB7XG4gICAgICBkdXJhdGlvbixcbiAgICAgIHN0YXR1cyxcbiAgICAgIC4uLmRldGFpbHMsXG4gICAgfSxcbiAgICBlcnJvcixcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCB7IHJ1biB9XG4iXX0=