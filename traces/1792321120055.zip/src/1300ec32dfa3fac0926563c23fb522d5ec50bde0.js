"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const messages_1 = require("@cucumber/messages");
const value_checker_1 = require("../value_checker");
const attachment_manager_1 = __importDefault(require("./attachment_manager"));
const make_suggestion_1 = require("./make_suggestion");
const step_runner_1 = __importDefault(require("./step_runner"));
const stopwatch_1 = require("./stopwatch");
class TestCaseRunner {
    workerId;
    attachmentManager;
    currentTestCaseStartedId;
    currentTestStepId;
    eventBroadcaster;
    gherkinDocument;
    newId;
    pickle;
    testCase;
    maxAttempts;
    skip;
    filterStackTraces;
    supportCodeLibrary;
    snippetBuilder;
    testStepResults;
    world;
    worldParameters;
    constructor({ workerId, eventBroadcaster, gherkinDocument, newId, pickle, testCase, retries = 0, skip, filterStackTraces, supportCodeLibrary, worldParameters, snippetBuilder, }) {
        this.workerId = workerId;
        this.attachmentManager = new attachment_manager_1.default(({ data, media, fileName }) => {
            if ((0, value_checker_1.doesNotHaveValue)(this.currentTestStepId)) {
                throw new Error('Cannot attach when a step/hook is not running. Ensure your step/hook waits for the attach to finish.');
            }
            const attachment = {
                attachment: {
                    body: data,
                    contentEncoding: media.encoding,
                    mediaType: media.contentType,
                    fileName,
                    testCaseStartedId: this.currentTestCaseStartedId,
                    testStepId: this.currentTestStepId,
                    timestamp: (0, stopwatch_1.timestamp)(),
                },
            };
            this.eventBroadcaster.emit('envelope', attachment);
        });
        this.eventBroadcaster = eventBroadcaster;
        this.gherkinDocument = gherkinDocument;
        this.maxAttempts = 1 + (skip ? 0 : retries);
        this.newId = newId;
        this.pickle = pickle;
        this.testCase = testCase;
        this.skip = skip;
        this.filterStackTraces = filterStackTraces;
        this.supportCodeLibrary = supportCodeLibrary;
        this.worldParameters = worldParameters;
        this.snippetBuilder = snippetBuilder;
        this.resetTestProgressData();
    }
    resetTestProgressData() {
        this.world = new this.supportCodeLibrary.World({
            attach: this.attachmentManager.create.bind(this.attachmentManager),
            log: this.attachmentManager.log.bind(this.attachmentManager),
            link: this.attachmentManager.link.bind(this.attachmentManager),
            parameters: structuredClone(this.worldParameters),
        });
        this.testStepResults = [];
    }
    getBeforeStepHookDefinitions() {
        return this.supportCodeLibrary.beforeTestStepHookDefinitions.filter((hookDefinition) => hookDefinition.appliesToTestCase(this.pickle));
    }
    getAfterStepHookDefinitions() {
        return this.supportCodeLibrary.afterTestStepHookDefinitions
            .slice(0)
            .reverse()
            .filter((hookDefinition) => hookDefinition.appliesToTestCase(this.pickle));
    }
    getWorstStepResult() {
        if (this.testStepResults.length === 0) {
            return {
                status: this.skip ? messages_1.TestStepResultStatus.SKIPPED : messages_1.TestStepResultStatus.PASSED,
                duration: messages_1.TimeConversion.millisecondsToDuration(0),
            };
        }
        return (0, messages_1.getWorstTestStepResult)(this.testStepResults);
    }
    async invokeStep(step, stepDefinition, hookParameter) {
        return await step_runner_1.default.run({
            defaultTimeout: this.supportCodeLibrary.defaultTimeout,
            filterStackTraces: this.filterStackTraces,
            hookParameter,
            step,
            stepDefinition,
            world: this.world,
        });
    }
    isSkippingSteps() {
        return this.getWorstStepResult().status !== messages_1.TestStepResultStatus.PASSED;
    }
    isExplicitlySkipped() {
        return !this.skip && this.getWorstStepResult().status === messages_1.TestStepResultStatus.SKIPPED;
    }
    shouldSkipHook(isBeforeHook) {
        return this.skip || (this.isSkippingSteps() && isBeforeHook);
    }
    async aroundTestStep(testStepId, runStepFn) {
        const testStepStarted = {
            testStepStarted: {
                testCaseStartedId: this.currentTestCaseStartedId,
                testStepId,
                timestamp: (0, stopwatch_1.timestamp)(),
            },
        };
        this.eventBroadcaster.emit('envelope', testStepStarted);
        this.currentTestStepId = testStepId;
        const testStepResult = await runStepFn();
        this.currentTestStepId = null;
        this.testStepResults.push(testStepResult);
        const testStepFinished = {
            testStepFinished: {
                testCaseStartedId: this.currentTestCaseStartedId,
                testStepId,
                testStepResult,
                timestamp: (0, stopwatch_1.timestamp)(),
            },
        };
        this.eventBroadcaster.emit('envelope', testStepFinished);
    }
    async run() {
        for (let attempt = 0; attempt < this.maxAttempts; attempt++) {
            const moreAttemptsRemaining = attempt + 1 < this.maxAttempts;
            const willBeRetried = await this.runAttempt(attempt, moreAttemptsRemaining);
            if (!willBeRetried) {
                break;
            }
            this.resetTestProgressData();
        }
        return this.getWorstStepResult().status;
    }
    async runAttempt(attempt, moreAttemptsRemaining) {
        this.currentTestCaseStartedId = this.newId();
        const testCaseStarted = {
            testCaseStarted: {
                attempt,
                testCaseId: this.testCase.id,
                id: this.currentTestCaseStartedId,
                timestamp: (0, stopwatch_1.timestamp)(),
            },
        };
        if (this.workerId) {
            testCaseStarted.testCaseStarted.workerId = this.workerId;
        }
        this.eventBroadcaster.emit('envelope', testCaseStarted);
        // used to determine whether a hook is a Before or After
        let didWeRunStepsYet = false;
        let error = false;
        for (const testStep of this.testCase.testSteps) {
            await this.aroundTestStep(testStep.id, async () => {
                if ((0, value_checker_1.doesHaveValue)(testStep.hookId)) {
                    const hookParameter = {
                        gherkinDocument: this.gherkinDocument,
                        pickle: this.pickle,
                        testCaseStartedId: this.currentTestCaseStartedId,
                    };
                    if (didWeRunStepsYet) {
                        hookParameter.result = this.getWorstStepResult();
                        hookParameter.error = error;
                        hookParameter.willBeRetried =
                            this.getWorstStepResult().status === messages_1.TestStepResultStatus.FAILED &&
                                moreAttemptsRemaining;
                    }
                    return await this.runHook(findHookDefinition(testStep.hookId, this.supportCodeLibrary), hookParameter, !didWeRunStepsYet);
                }
                else {
                    const pickleStep = this.pickle.steps.find((pickleStep) => pickleStep.id === testStep.pickleStepId);
                    const testStepResult = await this.runStep(pickleStep, testStep);
                    didWeRunStepsYet = true;
                    error = testStepResult.error;
                    return testStepResult.result;
                }
            });
        }
        const willBeRetried = this.getWorstStepResult().status === messages_1.TestStepResultStatus.FAILED && moreAttemptsRemaining;
        const testCaseFinished = {
            testCaseFinished: {
                testCaseStartedId: this.currentTestCaseStartedId,
                timestamp: (0, stopwatch_1.timestamp)(),
                willBeRetried,
            },
        };
        this.eventBroadcaster.emit('envelope', testCaseFinished);
        return willBeRetried;
    }
    async runHook(hookDefinition, hookParameter, isBeforeHook) {
        if (this.shouldSkipHook(isBeforeHook)) {
            return {
                status: messages_1.TestStepResultStatus.SKIPPED,
                duration: messages_1.TimeConversion.millisecondsToDuration(0),
            };
        }
        const { result } = await this.invokeStep(null, hookDefinition, hookParameter);
        return result;
    }
    async runStepHooks(stepHooks, pickleStep, stepResult) {
        const stepHooksResult = [];
        const hookParameter = {
            gherkinDocument: this.gherkinDocument,
            pickle: this.pickle,
            pickleStep,
            testCaseStartedId: this.currentTestCaseStartedId,
            testStepId: this.currentTestStepId,
            result: stepResult?.result,
            error: stepResult?.error,
        };
        for (const stepHookDefinition of stepHooks) {
            const { result } = await this.invokeStep(null, stepHookDefinition, hookParameter);
            stepHooksResult.push(result);
        }
        return stepHooksResult;
    }
    async runStep(pickleStep, testStep) {
        if (this.isExplicitlySkipped()) {
            return {
                result: {
                    status: messages_1.TestStepResultStatus.SKIPPED,
                    duration: messages_1.TimeConversion.millisecondsToDuration(0),
                },
            };
        }
        const stepDefinitions = testStep.stepDefinitionIds.map((stepDefinitionId) => {
            return findStepDefinition(stepDefinitionId, this.supportCodeLibrary);
        });
        if (stepDefinitions.length === 0) {
            this.eventBroadcaster.emit('envelope', {
                suggestion: (0, make_suggestion_1.makeSuggestion)({
                    newId: this.newId,
                    snippetBuilder: this.snippetBuilder,
                    pickleStep,
                }),
            });
            return {
                result: {
                    status: messages_1.TestStepResultStatus.UNDEFINED,
                    duration: messages_1.TimeConversion.millisecondsToDuration(0),
                },
            };
        }
        else if (stepDefinitions.length > 1) {
            return {
                result: {
                    status: messages_1.TestStepResultStatus.AMBIGUOUS,
                    duration: messages_1.TimeConversion.millisecondsToDuration(0),
                },
            };
        }
        else if (this.isSkippingSteps()) {
            return {
                result: {
                    status: messages_1.TestStepResultStatus.SKIPPED,
                    duration: messages_1.TimeConversion.millisecondsToDuration(0),
                },
            };
        }
        let stepResult;
        let error;
        let stepResults = await this.runStepHooks(this.getBeforeStepHookDefinitions(), pickleStep);
        if ((0, messages_1.getWorstTestStepResult)(stepResults).status !== messages_1.TestStepResultStatus.FAILED) {
            stepResult = await this.invokeStep(pickleStep, stepDefinitions[0]);
            stepResults.push(stepResult.result);
            error = stepResult.error;
        }
        const afterStepHookResults = await this.runStepHooks(this.getAfterStepHookDefinitions(), pickleStep, stepResult);
        stepResults = stepResults.concat(afterStepHookResults);
        const finalStepResult = (0, messages_1.getWorstTestStepResult)(stepResults);
        let finalDuration = messages_1.TimeConversion.millisecondsToDuration(0);
        for (const result of stepResults) {
            finalDuration = messages_1.TimeConversion.addDurations(finalDuration, result.duration);
        }
        finalStepResult.duration = finalDuration;
        return {
            result: finalStepResult,
            error,
        };
    }
}
exports.default = TestCaseRunner;
function findHookDefinition(id, supportCodeLibrary) {
    return [
        ...supportCodeLibrary.beforeTestCaseHookDefinitions,
        ...supportCodeLibrary.afterTestCaseHookDefinitions,
    ].find((definition) => definition.id === id);
}
function findStepDefinition(id, supportCodeLibrary) {
    return supportCodeLibrary.stepDefinitions.find((definition) => definition.id === id);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdF9jYXNlX3J1bm5lci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9ydW50aW1lL3Rlc3RfY2FzZV9ydW5uZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFDQSxpREFZMkI7QUFhM0Isb0RBQWtFO0FBQ2xFLDhFQUFvRDtBQUNwRCx1REFBa0Q7QUFDbEQsZ0VBQThEO0FBQzlELDJDQUF1QztBQWlCdkMsTUFBcUIsY0FBYztJQUNoQixRQUFRLENBQW9CO0lBQzVCLGlCQUFpQixDQUFtQjtJQUM3Qyx3QkFBd0IsQ0FBUTtJQUNoQyxpQkFBaUIsQ0FBUTtJQUNoQixnQkFBZ0IsQ0FBYztJQUM5QixlQUFlLENBQWlCO0lBQ2hDLEtBQUssQ0FBbUI7SUFDeEIsTUFBTSxDQUFRO0lBQ2QsUUFBUSxDQUFVO0lBQ2xCLFdBQVcsQ0FBUTtJQUNuQixJQUFJLENBQVM7SUFDYixpQkFBaUIsQ0FBUztJQUMxQixrQkFBa0IsQ0FBb0I7SUFDdEMsY0FBYyxDQUE4QjtJQUNyRCxlQUFlLENBQWtCO0lBQ2pDLEtBQUssQ0FBSztJQUNELGVBQWUsQ0FBWTtJQUU1QyxZQUFZLEVBQ1YsUUFBUSxFQUNSLGdCQUFnQixFQUNoQixlQUFlLEVBQ2YsS0FBSyxFQUNMLE1BQU0sRUFDTixRQUFRLEVBQ1IsT0FBTyxHQUFHLENBQUMsRUFDWCxJQUFJLEVBQ0osaUJBQWlCLEVBQ2pCLGtCQUFrQixFQUNsQixlQUFlLEVBQ2YsY0FBYyxHQUNZO1FBQzFCLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFBO1FBQ3hCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLDRCQUFpQixDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUU7WUFDM0UsSUFBSSxJQUFBLGdDQUFnQixFQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7Z0JBQzdDLE1BQU0sSUFBSSxLQUFLLENBQ2Isc0dBQXNHLENBQ3ZHLENBQUE7WUFDSCxDQUFDO1lBQ0QsTUFBTSxVQUFVLEdBQWE7Z0JBQzNCLFVBQVUsRUFBRTtvQkFDVixJQUFJLEVBQUUsSUFBSTtvQkFDVixlQUFlLEVBQUUsS0FBSyxDQUFDLFFBQVE7b0JBQy9CLFNBQVMsRUFBRSxLQUFLLENBQUMsV0FBVztvQkFDNUIsUUFBUTtvQkFDUixpQkFBaUIsRUFBRSxJQUFJLENBQUMsd0JBQXdCO29CQUNoRCxVQUFVLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjtvQkFDbEMsU0FBUyxFQUFFLElBQUEscUJBQVMsR0FBRTtpQkFDdkI7YUFDRixDQUFBO1lBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUE7UUFDcEQsQ0FBQyxDQUFDLENBQUE7UUFDRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsZ0JBQWdCLENBQUE7UUFDeEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUE7UUFDdEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUE7UUFDM0MsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUE7UUFDbEIsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUE7UUFDcEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUE7UUFDeEIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7UUFDaEIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLGlCQUFpQixDQUFBO1FBQzFDLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FBQTtRQUM1QyxJQUFJLENBQUMsZUFBZSxHQUFHLGVBQWUsQ0FBQTtRQUN0QyxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQTtRQUNwQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQTtJQUM5QixDQUFDO0lBRUQscUJBQXFCO1FBQ25CLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDO1lBQzdDLE1BQU0sRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7WUFDbEUsR0FBRyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztZQUM1RCxJQUFJLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQzlELFVBQVUsRUFBRSxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztTQUMxQixDQUFDLENBQUE7UUFDMUIsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUE7SUFDM0IsQ0FBQztJQUVELDRCQUE0QjtRQUMxQixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw2QkFBNkIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxjQUFjLEVBQUUsRUFBRSxDQUNyRixjQUFjLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUM5QyxDQUFBO0lBQ0gsQ0FBQztJQUVELDJCQUEyQjtRQUN6QixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyw0QkFBNEI7YUFDeEQsS0FBSyxDQUFDLENBQUMsQ0FBQzthQUNSLE9BQU8sRUFBRTthQUNULE1BQU0sQ0FBQyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUMsY0FBYyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO0lBQzlFLENBQUM7SUFFRCxrQkFBa0I7UUFDaEIsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPO2dCQUNMLE1BQU0sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQywrQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLCtCQUFvQixDQUFDLE1BQU07Z0JBQzlFLFFBQVEsRUFBRSx5QkFBYyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQzthQUNuRCxDQUFBO1FBQ0gsQ0FBQztRQUNELE9BQU8sSUFBQSxpQ0FBc0IsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUE7SUFDckQsQ0FBQztJQUVELEtBQUssQ0FBQyxVQUFVLENBQ2QsSUFBZ0IsRUFDaEIsY0FBMkIsRUFDM0IsYUFBc0M7UUFFdEMsT0FBTyxNQUFNLHFCQUFVLENBQUMsR0FBRyxDQUFDO1lBQzFCLGNBQWMsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsY0FBYztZQUN0RCxpQkFBaUIsRUFBRSxJQUFJLENBQUMsaUJBQWlCO1lBQ3pDLGFBQWE7WUFDYixJQUFJO1lBQ0osY0FBYztZQUNkLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztTQUNsQixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsZUFBZTtRQUNiLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsTUFBTSxLQUFLLCtCQUFvQixDQUFDLE1BQU0sQ0FBQTtJQUN6RSxDQUFDO0lBRUQsbUJBQW1CO1FBQ2pCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLE1BQU0sS0FBSywrQkFBb0IsQ0FBQyxPQUFPLENBQUE7SUFDeEYsQ0FBQztJQUVELGNBQWMsQ0FBQyxZQUFxQjtRQUNsQyxPQUFPLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLElBQUksWUFBWSxDQUFDLENBQUE7SUFDOUQsQ0FBQztJQUVELEtBQUssQ0FBQyxjQUFjLENBQ2xCLFVBQWtCLEVBQ2xCLFNBQXdDO1FBRXhDLE1BQU0sZUFBZSxHQUFhO1lBQ2hDLGVBQWUsRUFBRTtnQkFDZixpQkFBaUIsRUFBRSxJQUFJLENBQUMsd0JBQXdCO2dCQUNoRCxVQUFVO2dCQUNWLFNBQVMsRUFBRSxJQUFBLHFCQUFTLEdBQUU7YUFDdkI7U0FDRixDQUFBO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsZUFBZSxDQUFDLENBQUE7UUFDdkQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFVBQVUsQ0FBQTtRQUNuQyxNQUFNLGNBQWMsR0FBRyxNQUFNLFNBQVMsRUFBRSxDQUFBO1FBQ3hDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUE7UUFDN0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUE7UUFDekMsTUFBTSxnQkFBZ0IsR0FBYTtZQUNqQyxnQkFBZ0IsRUFBRTtnQkFDaEIsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLHdCQUF3QjtnQkFDaEQsVUFBVTtnQkFDVixjQUFjO2dCQUNkLFNBQVMsRUFBRSxJQUFBLHFCQUFTLEdBQUU7YUFDdkI7U0FDRixDQUFBO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQTtJQUMxRCxDQUFDO0lBRUQsS0FBSyxDQUFDLEdBQUc7UUFDUCxLQUFLLElBQUksT0FBTyxHQUFHLENBQUMsRUFBRSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDO1lBQzVELE1BQU0scUJBQXFCLEdBQUcsT0FBTyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFBO1lBRTVELE1BQU0sYUFBYSxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUscUJBQXFCLENBQUMsQ0FBQTtZQUUzRSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ25CLE1BQUs7WUFDUCxDQUFDO1lBQ0QsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUE7UUFDOUIsQ0FBQztRQUNELE9BQU8sSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsTUFBTSxDQUFBO0lBQ3pDLENBQUM7SUFFRCxLQUFLLENBQUMsVUFBVSxDQUFDLE9BQWUsRUFBRSxxQkFBOEI7UUFDOUQsSUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQTtRQUM1QyxNQUFNLGVBQWUsR0FBYTtZQUNoQyxlQUFlLEVBQUU7Z0JBQ2YsT0FBTztnQkFDUCxVQUFVLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFO2dCQUM1QixFQUFFLEVBQUUsSUFBSSxDQUFDLHdCQUF3QjtnQkFDakMsU0FBUyxFQUFFLElBQUEscUJBQVMsR0FBRTthQUN2QjtTQUNGLENBQUE7UUFDRCxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNsQixlQUFlLENBQUMsZUFBZSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFBO1FBQzFELENBQUM7UUFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQTtRQUN2RCx3REFBd0Q7UUFDeEQsSUFBSSxnQkFBZ0IsR0FBRyxLQUFLLENBQUE7UUFDNUIsSUFBSSxLQUFLLEdBQUcsS0FBSyxDQUFBO1FBQ2pCLEtBQUssTUFBTSxRQUFRLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUMvQyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxLQUFLLElBQUksRUFBRTtnQkFDaEQsSUFBSSxJQUFBLDZCQUFhLEVBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0JBQ25DLE1BQU0sYUFBYSxHQUEyQjt3QkFDNUMsZUFBZSxFQUFFLElBQUksQ0FBQyxlQUFlO3dCQUNyQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07d0JBQ25CLGlCQUFpQixFQUFFLElBQUksQ0FBQyx3QkFBd0I7cUJBQ2pELENBQUE7b0JBQ0QsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO3dCQUNyQixhQUFhLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFBO3dCQUNoRCxhQUFhLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQTt3QkFDM0IsYUFBYSxDQUFDLGFBQWE7NEJBQ3pCLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLE1BQU0sS0FBSywrQkFBb0IsQ0FBQyxNQUFNO2dDQUNoRSxxQkFBcUIsQ0FBQTtvQkFDekIsQ0FBQztvQkFDRCxPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FDdkIsa0JBQWtCLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFDNUQsYUFBYSxFQUNiLENBQUMsZ0JBQWdCLENBQ2xCLENBQUE7Z0JBQ0gsQ0FBQztxQkFBTSxDQUFDO29CQUNOLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FDdkMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssUUFBUSxDQUFDLFlBQVksQ0FDeEQsQ0FBQTtvQkFDRCxNQUFNLGNBQWMsR0FBRyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUFBO29CQUMvRCxnQkFBZ0IsR0FBRyxJQUFJLENBQUE7b0JBQ3ZCLEtBQUssR0FBRyxjQUFjLENBQUMsS0FBSyxDQUFBO29CQUM1QixPQUFPLGNBQWMsQ0FBQyxNQUFNLENBQUE7Z0JBQzlCLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxNQUFNLGFBQWEsR0FDakIsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsTUFBTSxLQUFLLCtCQUFvQixDQUFDLE1BQU0sSUFBSSxxQkFBcUIsQ0FBQTtRQUMzRixNQUFNLGdCQUFnQixHQUFhO1lBQ2pDLGdCQUFnQixFQUFFO2dCQUNoQixpQkFBaUIsRUFBRSxJQUFJLENBQUMsd0JBQXdCO2dCQUNoRCxTQUFTLEVBQUUsSUFBQSxxQkFBUyxHQUFFO2dCQUN0QixhQUFhO2FBQ2Q7U0FDRixDQUFBO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQTtRQUV4RCxPQUFPLGFBQWEsQ0FBQTtJQUN0QixDQUFDO0lBRUQsS0FBSyxDQUFDLE9BQU8sQ0FDWCxjQUFzQyxFQUN0QyxhQUFxQyxFQUNyQyxZQUFxQjtRQUVyQixJQUFJLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPO2dCQUNMLE1BQU0sRUFBRSwrQkFBb0IsQ0FBQyxPQUFPO2dCQUNwQyxRQUFRLEVBQUUseUJBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7YUFDbkQsQ0FBQTtRQUNILENBQUM7UUFDRCxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxjQUFjLEVBQUUsYUFBYSxDQUFDLENBQUE7UUFDN0UsT0FBTyxNQUFNLENBQUE7SUFDZixDQUFDO0lBRUQsS0FBSyxDQUFDLFlBQVksQ0FDaEIsU0FBbUMsRUFDbkMsVUFBc0IsRUFDdEIsVUFBMEI7UUFFMUIsTUFBTSxlQUFlLEdBQUcsRUFBRSxDQUFBO1FBQzFCLE1BQU0sYUFBYSxHQUEyQjtZQUM1QyxlQUFlLEVBQUUsSUFBSSxDQUFDLGVBQWU7WUFDckMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFVBQVU7WUFDVixpQkFBaUIsRUFBRSxJQUFJLENBQUMsd0JBQXdCO1lBQ2hELFVBQVUsRUFBRSxJQUFJLENBQUMsaUJBQWlCO1lBQ2xDLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTTtZQUMxQixLQUFLLEVBQUUsVUFBVSxFQUFFLEtBQUs7U0FDekIsQ0FBQTtRQUNELEtBQUssTUFBTSxrQkFBa0IsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMzQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxrQkFBa0IsRUFBRSxhQUFhLENBQUMsQ0FBQTtZQUNqRixlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQzlCLENBQUM7UUFDRCxPQUFPLGVBQWUsQ0FBQTtJQUN4QixDQUFDO0lBRUQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFzQixFQUFFLFFBQWtCO1FBQ3RELElBQUksSUFBSSxDQUFDLG1CQUFtQixFQUFFLEVBQUUsQ0FBQztZQUMvQixPQUFPO2dCQUNMLE1BQU0sRUFBRTtvQkFDTixNQUFNLEVBQUUsK0JBQW9CLENBQUMsT0FBTztvQkFDcEMsUUFBUSxFQUFFLHlCQUFjLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO2lCQUNuRDthQUNGLENBQUE7UUFDSCxDQUFDO1FBQ0QsTUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLGdCQUFnQixFQUFFLEVBQUU7WUFDMUUsT0FBTyxrQkFBa0IsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtRQUN0RSxDQUFDLENBQUMsQ0FBQTtRQUNGLElBQUksZUFBZSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNqQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRTtnQkFDckMsVUFBVSxFQUFFLElBQUEsZ0NBQWMsRUFBQztvQkFDekIsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLO29CQUNqQixjQUFjLEVBQUUsSUFBSSxDQUFDLGNBQWM7b0JBQ25DLFVBQVU7aUJBQ1gsQ0FBQzthQUNnQixDQUFDLENBQUE7WUFDckIsT0FBTztnQkFDTCxNQUFNLEVBQUU7b0JBQ04sTUFBTSxFQUFFLCtCQUFvQixDQUFDLFNBQVM7b0JBQ3RDLFFBQVEsRUFBRSx5QkFBYyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQztpQkFDbkQ7YUFDRixDQUFBO1FBQ0gsQ0FBQzthQUFNLElBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN0QyxPQUFPO2dCQUNMLE1BQU0sRUFBRTtvQkFDTixNQUFNLEVBQUUsK0JBQW9CLENBQUMsU0FBUztvQkFDdEMsUUFBUSxFQUFFLHlCQUFjLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO2lCQUNuRDthQUNGLENBQUE7UUFDSCxDQUFDO2FBQU0sSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUUsQ0FBQztZQUNsQyxPQUFPO2dCQUNMLE1BQU0sRUFBRTtvQkFDTixNQUFNLEVBQUUsK0JBQW9CLENBQUMsT0FBTztvQkFDcEMsUUFBUSxFQUFFLHlCQUFjLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO2lCQUNuRDthQUNGLENBQUE7UUFDSCxDQUFDO1FBRUQsSUFBSSxVQUFlLENBQUE7UUFDbkIsSUFBSSxLQUFVLENBQUE7UUFDZCxJQUFJLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLDRCQUE0QixFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUE7UUFDMUYsSUFBSSxJQUFBLGlDQUFzQixFQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sS0FBSywrQkFBb0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUMvRSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNsRSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQTtZQUNuQyxLQUFLLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQTtRQUMxQixDQUFDO1FBQ0QsTUFBTSxvQkFBb0IsR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQ2xELElBQUksQ0FBQywyQkFBMkIsRUFBRSxFQUNsQyxVQUFVLEVBQ1YsVUFBVSxDQUNYLENBQUE7UUFDRCxXQUFXLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO1FBRXRELE1BQU0sZUFBZSxHQUFHLElBQUEsaUNBQXNCLEVBQUMsV0FBVyxDQUFDLENBQUE7UUFDM0QsSUFBSSxhQUFhLEdBQUcseUJBQWMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUM1RCxLQUFLLE1BQU0sTUFBTSxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ2pDLGFBQWEsR0FBRyx5QkFBYyxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBQzdFLENBQUM7UUFDRCxlQUFlLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQTtRQUN4QyxPQUFPO1lBQ0wsTUFBTSxFQUFFLGVBQWU7WUFDdkIsS0FBSztTQUNOLENBQUE7SUFDSCxDQUFDO0NBQ0Y7QUFoVkQsaUNBZ1ZDO0FBRUQsU0FBUyxrQkFBa0IsQ0FDekIsRUFBVSxFQUNWLGtCQUFzQztJQUV0QyxPQUFPO1FBQ0wsR0FBRyxrQkFBa0IsQ0FBQyw2QkFBNkI7UUFDbkQsR0FBRyxrQkFBa0IsQ0FBQyw0QkFBNEI7S0FDbkQsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7QUFDOUMsQ0FBQztBQUVELFNBQVMsa0JBQWtCLENBQUMsRUFBVSxFQUFFLGtCQUFzQztJQUM1RSxPQUFPLGtCQUFrQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsRUFBRSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7QUFDdEYsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnbm9kZTpldmVudHMnXG5pbXBvcnQge1xuICB0eXBlIEVudmVsb3BlLFxuICB0eXBlIEdoZXJraW5Eb2N1bWVudCxcbiAgZ2V0V29yc3RUZXN0U3RlcFJlc3VsdCxcbiAgdHlwZSBJZEdlbmVyYXRvcixcbiAgdHlwZSBQaWNrbGUsXG4gIHR5cGUgUGlja2xlU3RlcCxcbiAgdHlwZSBUZXN0Q2FzZSxcbiAgdHlwZSBUZXN0U3RlcCxcbiAgdHlwZSBUZXN0U3RlcFJlc3VsdCxcbiAgVGVzdFN0ZXBSZXN1bHRTdGF0dXMsXG4gIFRpbWVDb252ZXJzaW9uLFxufSBmcm9tICdAY3VjdW1iZXIvbWVzc2FnZXMnXG5pbXBvcnQgdHlwZSB7IEpzb25PYmplY3QgfSBmcm9tICd0eXBlLWZlc3QnXG5pbXBvcnQgdHlwZSBTdGVwRGVmaW5pdGlvblNuaXBwZXRCdWlsZGVyIGZyb20gJy4uL2Zvcm1hdHRlci9zdGVwX2RlZmluaXRpb25fc25pcHBldF9idWlsZGVyJ1xuaW1wb3J0IHR5cGUgeyBJRGVmaW5pdGlvbiB9IGZyb20gJy4uL21vZGVscy9kZWZpbml0aW9uJ1xuaW1wb3J0IHR5cGUgU3RlcERlZmluaXRpb24gZnJvbSAnLi4vbW9kZWxzL3N0ZXBfZGVmaW5pdGlvbidcbmltcG9ydCB0eXBlIFRlc3RDYXNlSG9va0RlZmluaXRpb24gZnJvbSAnLi4vbW9kZWxzL3Rlc3RfY2FzZV9ob29rX2RlZmluaXRpb24nXG5pbXBvcnQgdHlwZSBUZXN0U3RlcEhvb2tEZWZpbml0aW9uIGZyb20gJy4uL21vZGVscy90ZXN0X3N0ZXBfaG9va19kZWZpbml0aW9uJ1xuaW1wb3J0IHR5cGUge1xuICBJVGVzdENhc2VIb29rUGFyYW1ldGVyLFxuICBJVGVzdFN0ZXBIb29rUGFyYW1ldGVyLFxuICBTdXBwb3J0Q29kZUxpYnJhcnksXG59IGZyb20gJy4uL3N1cHBvcnRfY29kZV9saWJyYXJ5X2J1aWxkZXIvdHlwZXMnXG5pbXBvcnQgdHlwZSB7IElXb3JsZE9wdGlvbnMgfSBmcm9tICcuLi9zdXBwb3J0X2NvZGVfbGlicmFyeV9idWlsZGVyL3dvcmxkJ1xuaW1wb3J0IHsgZG9lc0hhdmVWYWx1ZSwgZG9lc05vdEhhdmVWYWx1ZSB9IGZyb20gJy4uL3ZhbHVlX2NoZWNrZXInXG5pbXBvcnQgQXR0YWNobWVudE1hbmFnZXIgZnJvbSAnLi9hdHRhY2htZW50X21hbmFnZXInXG5pbXBvcnQgeyBtYWtlU3VnZ2VzdGlvbiB9IGZyb20gJy4vbWFrZV9zdWdnZXN0aW9uJ1xuaW1wb3J0IFN0ZXBSdW5uZXIsIHsgdHlwZSBSdW5TdGVwUmVzdWx0IH0gZnJvbSAnLi9zdGVwX3J1bm5lcidcbmltcG9ydCB7IHRpbWVzdGFtcCB9IGZyb20gJy4vc3RvcHdhdGNoJ1xuXG5leHBvcnQgaW50ZXJmYWNlIElOZXdUZXN0Q2FzZVJ1bm5lck9wdGlvbnMge1xuICB3b3JrZXJJZD86IHN0cmluZ1xuICBldmVudEJyb2FkY2FzdGVyOiBFdmVudEVtaXR0ZXJcbiAgZ2hlcmtpbkRvY3VtZW50OiBHaGVya2luRG9jdW1lbnRcbiAgbmV3SWQ6IElkR2VuZXJhdG9yLk5ld0lkXG4gIHBpY2tsZTogUGlja2xlXG4gIHRlc3RDYXNlOiBUZXN0Q2FzZVxuICByZXRyaWVzOiBudW1iZXJcbiAgc2tpcDogYm9vbGVhblxuICBmaWx0ZXJTdGFja1RyYWNlczogYm9vbGVhblxuICBzdXBwb3J0Q29kZUxpYnJhcnk6IFN1cHBvcnRDb2RlTGlicmFyeVxuICB3b3JsZFBhcmFtZXRlcnM6IEpzb25PYmplY3RcbiAgc25pcHBldEJ1aWxkZXI6IFN0ZXBEZWZpbml0aW9uU25pcHBldEJ1aWxkZXJcbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGVzdENhc2VSdW5uZXIge1xuICBwcml2YXRlIHJlYWRvbmx5IHdvcmtlcklkOiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgcHJpdmF0ZSByZWFkb25seSBhdHRhY2htZW50TWFuYWdlcjogQXR0YWNobWVudE1hbmFnZXJcbiAgcHJpdmF0ZSBjdXJyZW50VGVzdENhc2VTdGFydGVkSWQ6IHN0cmluZ1xuICBwcml2YXRlIGN1cnJlbnRUZXN0U3RlcElkOiBzdHJpbmdcbiAgcHJpdmF0ZSByZWFkb25seSBldmVudEJyb2FkY2FzdGVyOiBFdmVudEVtaXR0ZXJcbiAgcHJpdmF0ZSByZWFkb25seSBnaGVya2luRG9jdW1lbnQ6IEdoZXJraW5Eb2N1bWVudFxuICBwcml2YXRlIHJlYWRvbmx5IG5ld0lkOiBJZEdlbmVyYXRvci5OZXdJZFxuICBwcml2YXRlIHJlYWRvbmx5IHBpY2tsZTogUGlja2xlXG4gIHByaXZhdGUgcmVhZG9ubHkgdGVzdENhc2U6IFRlc3RDYXNlXG4gIHByaXZhdGUgcmVhZG9ubHkgbWF4QXR0ZW1wdHM6IG51bWJlclxuICBwcml2YXRlIHJlYWRvbmx5IHNraXA6IGJvb2xlYW5cbiAgcHJpdmF0ZSByZWFkb25seSBmaWx0ZXJTdGFja1RyYWNlczogYm9vbGVhblxuICBwcml2YXRlIHJlYWRvbmx5IHN1cHBvcnRDb2RlTGlicmFyeTogU3VwcG9ydENvZGVMaWJyYXJ5XG4gIHByaXZhdGUgcmVhZG9ubHkgc25pcHBldEJ1aWxkZXI6IFN0ZXBEZWZpbml0aW9uU25pcHBldEJ1aWxkZXJcbiAgcHJpdmF0ZSB0ZXN0U3RlcFJlc3VsdHM6IFRlc3RTdGVwUmVzdWx0W11cbiAgcHJpdmF0ZSB3b3JsZDogYW55XG4gIHByaXZhdGUgcmVhZG9ubHkgd29ybGRQYXJhbWV0ZXJzOiBKc29uT2JqZWN0XG5cbiAgY29uc3RydWN0b3Ioe1xuICAgIHdvcmtlcklkLFxuICAgIGV2ZW50QnJvYWRjYXN0ZXIsXG4gICAgZ2hlcmtpbkRvY3VtZW50LFxuICAgIG5ld0lkLFxuICAgIHBpY2tsZSxcbiAgICB0ZXN0Q2FzZSxcbiAgICByZXRyaWVzID0gMCxcbiAgICBza2lwLFxuICAgIGZpbHRlclN0YWNrVHJhY2VzLFxuICAgIHN1cHBvcnRDb2RlTGlicmFyeSxcbiAgICB3b3JsZFBhcmFtZXRlcnMsXG4gICAgc25pcHBldEJ1aWxkZXIsXG4gIH06IElOZXdUZXN0Q2FzZVJ1bm5lck9wdGlvbnMpIHtcbiAgICB0aGlzLndvcmtlcklkID0gd29ya2VySWRcbiAgICB0aGlzLmF0dGFjaG1lbnRNYW5hZ2VyID0gbmV3IEF0dGFjaG1lbnRNYW5hZ2VyKCh7IGRhdGEsIG1lZGlhLCBmaWxlTmFtZSB9KSA9PiB7XG4gICAgICBpZiAoZG9lc05vdEhhdmVWYWx1ZSh0aGlzLmN1cnJlbnRUZXN0U3RlcElkKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgJ0Nhbm5vdCBhdHRhY2ggd2hlbiBhIHN0ZXAvaG9vayBpcyBub3QgcnVubmluZy4gRW5zdXJlIHlvdXIgc3RlcC9ob29rIHdhaXRzIGZvciB0aGUgYXR0YWNoIHRvIGZpbmlzaC4nXG4gICAgICAgIClcbiAgICAgIH1cbiAgICAgIGNvbnN0IGF0dGFjaG1lbnQ6IEVudmVsb3BlID0ge1xuICAgICAgICBhdHRhY2htZW50OiB7XG4gICAgICAgICAgYm9keTogZGF0YSxcbiAgICAgICAgICBjb250ZW50RW5jb2Rpbmc6IG1lZGlhLmVuY29kaW5nLFxuICAgICAgICAgIG1lZGlhVHlwZTogbWVkaWEuY29udGVudFR5cGUsXG4gICAgICAgICAgZmlsZU5hbWUsXG4gICAgICAgICAgdGVzdENhc2VTdGFydGVkSWQ6IHRoaXMuY3VycmVudFRlc3RDYXNlU3RhcnRlZElkLFxuICAgICAgICAgIHRlc3RTdGVwSWQ6IHRoaXMuY3VycmVudFRlc3RTdGVwSWQsXG4gICAgICAgICAgdGltZXN0YW1wOiB0aW1lc3RhbXAoKSxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICAgIHRoaXMuZXZlbnRCcm9hZGNhc3Rlci5lbWl0KCdlbnZlbG9wZScsIGF0dGFjaG1lbnQpXG4gICAgfSlcbiAgICB0aGlzLmV2ZW50QnJvYWRjYXN0ZXIgPSBldmVudEJyb2FkY2FzdGVyXG4gICAgdGhpcy5naGVya2luRG9jdW1lbnQgPSBnaGVya2luRG9jdW1lbnRcbiAgICB0aGlzLm1heEF0dGVtcHRzID0gMSArIChza2lwID8gMCA6IHJldHJpZXMpXG4gICAgdGhpcy5uZXdJZCA9IG5ld0lkXG4gICAgdGhpcy5waWNrbGUgPSBwaWNrbGVcbiAgICB0aGlzLnRlc3RDYXNlID0gdGVzdENhc2VcbiAgICB0aGlzLnNraXAgPSBza2lwXG4gICAgdGhpcy5maWx0ZXJTdGFja1RyYWNlcyA9IGZpbHRlclN0YWNrVHJhY2VzXG4gICAgdGhpcy5zdXBwb3J0Q29kZUxpYnJhcnkgPSBzdXBwb3J0Q29kZUxpYnJhcnlcbiAgICB0aGlzLndvcmxkUGFyYW1ldGVycyA9IHdvcmxkUGFyYW1ldGVyc1xuICAgIHRoaXMuc25pcHBldEJ1aWxkZXIgPSBzbmlwcGV0QnVpbGRlclxuICAgIHRoaXMucmVzZXRUZXN0UHJvZ3Jlc3NEYXRhKClcbiAgfVxuXG4gIHJlc2V0VGVzdFByb2dyZXNzRGF0YSgpOiB2b2lkIHtcbiAgICB0aGlzLndvcmxkID0gbmV3IHRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5LldvcmxkKHtcbiAgICAgIGF0dGFjaDogdGhpcy5hdHRhY2htZW50TWFuYWdlci5jcmVhdGUuYmluZCh0aGlzLmF0dGFjaG1lbnRNYW5hZ2VyKSxcbiAgICAgIGxvZzogdGhpcy5hdHRhY2htZW50TWFuYWdlci5sb2cuYmluZCh0aGlzLmF0dGFjaG1lbnRNYW5hZ2VyKSxcbiAgICAgIGxpbms6IHRoaXMuYXR0YWNobWVudE1hbmFnZXIubGluay5iaW5kKHRoaXMuYXR0YWNobWVudE1hbmFnZXIpLFxuICAgICAgcGFyYW1ldGVyczogc3RydWN0dXJlZENsb25lKHRoaXMud29ybGRQYXJhbWV0ZXJzKSxcbiAgICB9IHNhdGlzZmllcyBJV29ybGRPcHRpb25zKVxuICAgIHRoaXMudGVzdFN0ZXBSZXN1bHRzID0gW11cbiAgfVxuXG4gIGdldEJlZm9yZVN0ZXBIb29rRGVmaW5pdGlvbnMoKTogVGVzdFN0ZXBIb29rRGVmaW5pdGlvbltdIHtcbiAgICByZXR1cm4gdGhpcy5zdXBwb3J0Q29kZUxpYnJhcnkuYmVmb3JlVGVzdFN0ZXBIb29rRGVmaW5pdGlvbnMuZmlsdGVyKChob29rRGVmaW5pdGlvbikgPT5cbiAgICAgIGhvb2tEZWZpbml0aW9uLmFwcGxpZXNUb1Rlc3RDYXNlKHRoaXMucGlja2xlKVxuICAgIClcbiAgfVxuXG4gIGdldEFmdGVyU3RlcEhvb2tEZWZpbml0aW9ucygpOiBUZXN0U3RlcEhvb2tEZWZpbml0aW9uW10ge1xuICAgIHJldHVybiB0aGlzLnN1cHBvcnRDb2RlTGlicmFyeS5hZnRlclRlc3RTdGVwSG9va0RlZmluaXRpb25zXG4gICAgICAuc2xpY2UoMClcbiAgICAgIC5yZXZlcnNlKClcbiAgICAgIC5maWx0ZXIoKGhvb2tEZWZpbml0aW9uKSA9PiBob29rRGVmaW5pdGlvbi5hcHBsaWVzVG9UZXN0Q2FzZSh0aGlzLnBpY2tsZSkpXG4gIH1cblxuICBnZXRXb3JzdFN0ZXBSZXN1bHQoKTogVGVzdFN0ZXBSZXN1bHQge1xuICAgIGlmICh0aGlzLnRlc3RTdGVwUmVzdWx0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1czogdGhpcy5za2lwID8gVGVzdFN0ZXBSZXN1bHRTdGF0dXMuU0tJUFBFRCA6IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlBBU1NFRCxcbiAgICAgICAgZHVyYXRpb246IFRpbWVDb252ZXJzaW9uLm1pbGxpc2Vjb25kc1RvRHVyYXRpb24oMCksXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBnZXRXb3JzdFRlc3RTdGVwUmVzdWx0KHRoaXMudGVzdFN0ZXBSZXN1bHRzKVxuICB9XG5cbiAgYXN5bmMgaW52b2tlU3RlcChcbiAgICBzdGVwOiBQaWNrbGVTdGVwLFxuICAgIHN0ZXBEZWZpbml0aW9uOiBJRGVmaW5pdGlvbixcbiAgICBob29rUGFyYW1ldGVyPzogSVRlc3RDYXNlSG9va1BhcmFtZXRlclxuICApOiBQcm9taXNlPFJ1blN0ZXBSZXN1bHQ+IHtcbiAgICByZXR1cm4gYXdhaXQgU3RlcFJ1bm5lci5ydW4oe1xuICAgICAgZGVmYXVsdFRpbWVvdXQ6IHRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5LmRlZmF1bHRUaW1lb3V0LFxuICAgICAgZmlsdGVyU3RhY2tUcmFjZXM6IHRoaXMuZmlsdGVyU3RhY2tUcmFjZXMsXG4gICAgICBob29rUGFyYW1ldGVyLFxuICAgICAgc3RlcCxcbiAgICAgIHN0ZXBEZWZpbml0aW9uLFxuICAgICAgd29ybGQ6IHRoaXMud29ybGQsXG4gICAgfSlcbiAgfVxuXG4gIGlzU2tpcHBpbmdTdGVwcygpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5nZXRXb3JzdFN0ZXBSZXN1bHQoKS5zdGF0dXMgIT09IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlBBU1NFRFxuICB9XG5cbiAgaXNFeHBsaWNpdGx5U2tpcHBlZCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gIXRoaXMuc2tpcCAmJiB0aGlzLmdldFdvcnN0U3RlcFJlc3VsdCgpLnN0YXR1cyA9PT0gVGVzdFN0ZXBSZXN1bHRTdGF0dXMuU0tJUFBFRFxuICB9XG5cbiAgc2hvdWxkU2tpcEhvb2soaXNCZWZvcmVIb29rOiBib29sZWFuKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuc2tpcCB8fCAodGhpcy5pc1NraXBwaW5nU3RlcHMoKSAmJiBpc0JlZm9yZUhvb2spXG4gIH1cblxuICBhc3luYyBhcm91bmRUZXN0U3RlcChcbiAgICB0ZXN0U3RlcElkOiBzdHJpbmcsXG4gICAgcnVuU3RlcEZuOiAoKSA9PiBQcm9taXNlPFRlc3RTdGVwUmVzdWx0PlxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB0ZXN0U3RlcFN0YXJ0ZWQ6IEVudmVsb3BlID0ge1xuICAgICAgdGVzdFN0ZXBTdGFydGVkOiB7XG4gICAgICAgIHRlc3RDYXNlU3RhcnRlZElkOiB0aGlzLmN1cnJlbnRUZXN0Q2FzZVN0YXJ0ZWRJZCxcbiAgICAgICAgdGVzdFN0ZXBJZCxcbiAgICAgICAgdGltZXN0YW1wOiB0aW1lc3RhbXAoKSxcbiAgICAgIH0sXG4gICAgfVxuICAgIHRoaXMuZXZlbnRCcm9hZGNhc3Rlci5lbWl0KCdlbnZlbG9wZScsIHRlc3RTdGVwU3RhcnRlZClcbiAgICB0aGlzLmN1cnJlbnRUZXN0U3RlcElkID0gdGVzdFN0ZXBJZFxuICAgIGNvbnN0IHRlc3RTdGVwUmVzdWx0ID0gYXdhaXQgcnVuU3RlcEZuKClcbiAgICB0aGlzLmN1cnJlbnRUZXN0U3RlcElkID0gbnVsbFxuICAgIHRoaXMudGVzdFN0ZXBSZXN1bHRzLnB1c2godGVzdFN0ZXBSZXN1bHQpXG4gICAgY29uc3QgdGVzdFN0ZXBGaW5pc2hlZDogRW52ZWxvcGUgPSB7XG4gICAgICB0ZXN0U3RlcEZpbmlzaGVkOiB7XG4gICAgICAgIHRlc3RDYXNlU3RhcnRlZElkOiB0aGlzLmN1cnJlbnRUZXN0Q2FzZVN0YXJ0ZWRJZCxcbiAgICAgICAgdGVzdFN0ZXBJZCxcbiAgICAgICAgdGVzdFN0ZXBSZXN1bHQsXG4gICAgICAgIHRpbWVzdGFtcDogdGltZXN0YW1wKCksXG4gICAgICB9LFxuICAgIH1cbiAgICB0aGlzLmV2ZW50QnJvYWRjYXN0ZXIuZW1pdCgnZW52ZWxvcGUnLCB0ZXN0U3RlcEZpbmlzaGVkKVxuICB9XG5cbiAgYXN5bmMgcnVuKCk6IFByb21pc2U8VGVzdFN0ZXBSZXN1bHRTdGF0dXM+IHtcbiAgICBmb3IgKGxldCBhdHRlbXB0ID0gMDsgYXR0ZW1wdCA8IHRoaXMubWF4QXR0ZW1wdHM7IGF0dGVtcHQrKykge1xuICAgICAgY29uc3QgbW9yZUF0dGVtcHRzUmVtYWluaW5nID0gYXR0ZW1wdCArIDEgPCB0aGlzLm1heEF0dGVtcHRzXG5cbiAgICAgIGNvbnN0IHdpbGxCZVJldHJpZWQgPSBhd2FpdCB0aGlzLnJ1bkF0dGVtcHQoYXR0ZW1wdCwgbW9yZUF0dGVtcHRzUmVtYWluaW5nKVxuXG4gICAgICBpZiAoIXdpbGxCZVJldHJpZWQpIHtcbiAgICAgICAgYnJlYWtcbiAgICAgIH1cbiAgICAgIHRoaXMucmVzZXRUZXN0UHJvZ3Jlc3NEYXRhKClcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZ2V0V29yc3RTdGVwUmVzdWx0KCkuc3RhdHVzXG4gIH1cblxuICBhc3luYyBydW5BdHRlbXB0KGF0dGVtcHQ6IG51bWJlciwgbW9yZUF0dGVtcHRzUmVtYWluaW5nOiBib29sZWFuKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdGhpcy5jdXJyZW50VGVzdENhc2VTdGFydGVkSWQgPSB0aGlzLm5ld0lkKClcbiAgICBjb25zdCB0ZXN0Q2FzZVN0YXJ0ZWQ6IEVudmVsb3BlID0ge1xuICAgICAgdGVzdENhc2VTdGFydGVkOiB7XG4gICAgICAgIGF0dGVtcHQsXG4gICAgICAgIHRlc3RDYXNlSWQ6IHRoaXMudGVzdENhc2UuaWQsXG4gICAgICAgIGlkOiB0aGlzLmN1cnJlbnRUZXN0Q2FzZVN0YXJ0ZWRJZCxcbiAgICAgICAgdGltZXN0YW1wOiB0aW1lc3RhbXAoKSxcbiAgICAgIH0sXG4gICAgfVxuICAgIGlmICh0aGlzLndvcmtlcklkKSB7XG4gICAgICB0ZXN0Q2FzZVN0YXJ0ZWQudGVzdENhc2VTdGFydGVkLndvcmtlcklkID0gdGhpcy53b3JrZXJJZFxuICAgIH1cbiAgICB0aGlzLmV2ZW50QnJvYWRjYXN0ZXIuZW1pdCgnZW52ZWxvcGUnLCB0ZXN0Q2FzZVN0YXJ0ZWQpXG4gICAgLy8gdXNlZCB0byBkZXRlcm1pbmUgd2hldGhlciBhIGhvb2sgaXMgYSBCZWZvcmUgb3IgQWZ0ZXJcbiAgICBsZXQgZGlkV2VSdW5TdGVwc1lldCA9IGZhbHNlXG4gICAgbGV0IGVycm9yID0gZmFsc2VcbiAgICBmb3IgKGNvbnN0IHRlc3RTdGVwIG9mIHRoaXMudGVzdENhc2UudGVzdFN0ZXBzKSB7XG4gICAgICBhd2FpdCB0aGlzLmFyb3VuZFRlc3RTdGVwKHRlc3RTdGVwLmlkLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGlmIChkb2VzSGF2ZVZhbHVlKHRlc3RTdGVwLmhvb2tJZCkpIHtcbiAgICAgICAgICBjb25zdCBob29rUGFyYW1ldGVyOiBJVGVzdENhc2VIb29rUGFyYW1ldGVyID0ge1xuICAgICAgICAgICAgZ2hlcmtpbkRvY3VtZW50OiB0aGlzLmdoZXJraW5Eb2N1bWVudCxcbiAgICAgICAgICAgIHBpY2tsZTogdGhpcy5waWNrbGUsXG4gICAgICAgICAgICB0ZXN0Q2FzZVN0YXJ0ZWRJZDogdGhpcy5jdXJyZW50VGVzdENhc2VTdGFydGVkSWQsXG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChkaWRXZVJ1blN0ZXBzWWV0KSB7XG4gICAgICAgICAgICBob29rUGFyYW1ldGVyLnJlc3VsdCA9IHRoaXMuZ2V0V29yc3RTdGVwUmVzdWx0KClcbiAgICAgICAgICAgIGhvb2tQYXJhbWV0ZXIuZXJyb3IgPSBlcnJvclxuICAgICAgICAgICAgaG9va1BhcmFtZXRlci53aWxsQmVSZXRyaWVkID1cbiAgICAgICAgICAgICAgdGhpcy5nZXRXb3JzdFN0ZXBSZXN1bHQoKS5zdGF0dXMgPT09IFRlc3RTdGVwUmVzdWx0U3RhdHVzLkZBSUxFRCAmJlxuICAgICAgICAgICAgICBtb3JlQXR0ZW1wdHNSZW1haW5pbmdcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMucnVuSG9vayhcbiAgICAgICAgICAgIGZpbmRIb29rRGVmaW5pdGlvbih0ZXN0U3RlcC5ob29rSWQsIHRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5KSxcbiAgICAgICAgICAgIGhvb2tQYXJhbWV0ZXIsXG4gICAgICAgICAgICAhZGlkV2VSdW5TdGVwc1lldFxuICAgICAgICAgIClcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCBwaWNrbGVTdGVwID0gdGhpcy5waWNrbGUuc3RlcHMuZmluZChcbiAgICAgICAgICAgIChwaWNrbGVTdGVwKSA9PiBwaWNrbGVTdGVwLmlkID09PSB0ZXN0U3RlcC5waWNrbGVTdGVwSWRcbiAgICAgICAgICApXG4gICAgICAgICAgY29uc3QgdGVzdFN0ZXBSZXN1bHQgPSBhd2FpdCB0aGlzLnJ1blN0ZXAocGlja2xlU3RlcCwgdGVzdFN0ZXApXG4gICAgICAgICAgZGlkV2VSdW5TdGVwc1lldCA9IHRydWVcbiAgICAgICAgICBlcnJvciA9IHRlc3RTdGVwUmVzdWx0LmVycm9yXG4gICAgICAgICAgcmV0dXJuIHRlc3RTdGVwUmVzdWx0LnJlc3VsdFxuICAgICAgICB9XG4gICAgICB9KVxuICAgIH1cblxuICAgIGNvbnN0IHdpbGxCZVJldHJpZWQgPVxuICAgICAgdGhpcy5nZXRXb3JzdFN0ZXBSZXN1bHQoKS5zdGF0dXMgPT09IFRlc3RTdGVwUmVzdWx0U3RhdHVzLkZBSUxFRCAmJiBtb3JlQXR0ZW1wdHNSZW1haW5pbmdcbiAgICBjb25zdCB0ZXN0Q2FzZUZpbmlzaGVkOiBFbnZlbG9wZSA9IHtcbiAgICAgIHRlc3RDYXNlRmluaXNoZWQ6IHtcbiAgICAgICAgdGVzdENhc2VTdGFydGVkSWQ6IHRoaXMuY3VycmVudFRlc3RDYXNlU3RhcnRlZElkLFxuICAgICAgICB0aW1lc3RhbXA6IHRpbWVzdGFtcCgpLFxuICAgICAgICB3aWxsQmVSZXRyaWVkLFxuICAgICAgfSxcbiAgICB9XG4gICAgdGhpcy5ldmVudEJyb2FkY2FzdGVyLmVtaXQoJ2VudmVsb3BlJywgdGVzdENhc2VGaW5pc2hlZClcblxuICAgIHJldHVybiB3aWxsQmVSZXRyaWVkXG4gIH1cblxuICBhc3luYyBydW5Ib29rKFxuICAgIGhvb2tEZWZpbml0aW9uOiBUZXN0Q2FzZUhvb2tEZWZpbml0aW9uLFxuICAgIGhvb2tQYXJhbWV0ZXI6IElUZXN0Q2FzZUhvb2tQYXJhbWV0ZXIsXG4gICAgaXNCZWZvcmVIb29rOiBib29sZWFuXG4gICk6IFByb21pc2U8VGVzdFN0ZXBSZXN1bHQ+IHtcbiAgICBpZiAodGhpcy5zaG91bGRTa2lwSG9vayhpc0JlZm9yZUhvb2spKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdGF0dXM6IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlNLSVBQRUQsXG4gICAgICAgIGR1cmF0aW9uOiBUaW1lQ29udmVyc2lvbi5taWxsaXNlY29uZHNUb0R1cmF0aW9uKDApLFxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCB7IHJlc3VsdCB9ID0gYXdhaXQgdGhpcy5pbnZva2VTdGVwKG51bGwsIGhvb2tEZWZpbml0aW9uLCBob29rUGFyYW1ldGVyKVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxuXG4gIGFzeW5jIHJ1blN0ZXBIb29rcyhcbiAgICBzdGVwSG9va3M6IFRlc3RTdGVwSG9va0RlZmluaXRpb25bXSxcbiAgICBwaWNrbGVTdGVwOiBQaWNrbGVTdGVwLFxuICAgIHN0ZXBSZXN1bHQ/OiBSdW5TdGVwUmVzdWx0XG4gICk6IFByb21pc2U8VGVzdFN0ZXBSZXN1bHRbXT4ge1xuICAgIGNvbnN0IHN0ZXBIb29rc1Jlc3VsdCA9IFtdXG4gICAgY29uc3QgaG9va1BhcmFtZXRlcjogSVRlc3RTdGVwSG9va1BhcmFtZXRlciA9IHtcbiAgICAgIGdoZXJraW5Eb2N1bWVudDogdGhpcy5naGVya2luRG9jdW1lbnQsXG4gICAgICBwaWNrbGU6IHRoaXMucGlja2xlLFxuICAgICAgcGlja2xlU3RlcCxcbiAgICAgIHRlc3RDYXNlU3RhcnRlZElkOiB0aGlzLmN1cnJlbnRUZXN0Q2FzZVN0YXJ0ZWRJZCxcbiAgICAgIHRlc3RTdGVwSWQ6IHRoaXMuY3VycmVudFRlc3RTdGVwSWQsXG4gICAgICByZXN1bHQ6IHN0ZXBSZXN1bHQ/LnJlc3VsdCxcbiAgICAgIGVycm9yOiBzdGVwUmVzdWx0Py5lcnJvcixcbiAgICB9XG4gICAgZm9yIChjb25zdCBzdGVwSG9va0RlZmluaXRpb24gb2Ygc3RlcEhvb2tzKSB7XG4gICAgICBjb25zdCB7IHJlc3VsdCB9ID0gYXdhaXQgdGhpcy5pbnZva2VTdGVwKG51bGwsIHN0ZXBIb29rRGVmaW5pdGlvbiwgaG9va1BhcmFtZXRlcilcbiAgICAgIHN0ZXBIb29rc1Jlc3VsdC5wdXNoKHJlc3VsdClcbiAgICB9XG4gICAgcmV0dXJuIHN0ZXBIb29rc1Jlc3VsdFxuICB9XG5cbiAgYXN5bmMgcnVuU3RlcChwaWNrbGVTdGVwOiBQaWNrbGVTdGVwLCB0ZXN0U3RlcDogVGVzdFN0ZXApOiBQcm9taXNlPFJ1blN0ZXBSZXN1bHQ+IHtcbiAgICBpZiAodGhpcy5pc0V4cGxpY2l0bHlTa2lwcGVkKCkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHJlc3VsdDoge1xuICAgICAgICAgIHN0YXR1czogVGVzdFN0ZXBSZXN1bHRTdGF0dXMuU0tJUFBFRCxcbiAgICAgICAgICBkdXJhdGlvbjogVGltZUNvbnZlcnNpb24ubWlsbGlzZWNvbmRzVG9EdXJhdGlvbigwKSxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc3RlcERlZmluaXRpb25zID0gdGVzdFN0ZXAuc3RlcERlZmluaXRpb25JZHMubWFwKChzdGVwRGVmaW5pdGlvbklkKSA9PiB7XG4gICAgICByZXR1cm4gZmluZFN0ZXBEZWZpbml0aW9uKHN0ZXBEZWZpbml0aW9uSWQsIHRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5KVxuICAgIH0pXG4gICAgaWYgKHN0ZXBEZWZpbml0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRoaXMuZXZlbnRCcm9hZGNhc3Rlci5lbWl0KCdlbnZlbG9wZScsIHtcbiAgICAgICAgc3VnZ2VzdGlvbjogbWFrZVN1Z2dlc3Rpb24oe1xuICAgICAgICAgIG5ld0lkOiB0aGlzLm5ld0lkLFxuICAgICAgICAgIHNuaXBwZXRCdWlsZGVyOiB0aGlzLnNuaXBwZXRCdWlsZGVyLFxuICAgICAgICAgIHBpY2tsZVN0ZXAsXG4gICAgICAgIH0pLFxuICAgICAgfSBzYXRpc2ZpZXMgRW52ZWxvcGUpXG4gICAgICByZXR1cm4ge1xuICAgICAgICByZXN1bHQ6IHtcbiAgICAgICAgICBzdGF0dXM6IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlVOREVGSU5FRCxcbiAgICAgICAgICBkdXJhdGlvbjogVGltZUNvbnZlcnNpb24ubWlsbGlzZWNvbmRzVG9EdXJhdGlvbigwKSxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHN0ZXBEZWZpbml0aW9ucy5sZW5ndGggPiAxKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICByZXN1bHQ6IHtcbiAgICAgICAgICBzdGF0dXM6IFRlc3RTdGVwUmVzdWx0U3RhdHVzLkFNQklHVU9VUyxcbiAgICAgICAgICBkdXJhdGlvbjogVGltZUNvbnZlcnNpb24ubWlsbGlzZWNvbmRzVG9EdXJhdGlvbigwKSxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHRoaXMuaXNTa2lwcGluZ1N0ZXBzKCkpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHJlc3VsdDoge1xuICAgICAgICAgIHN0YXR1czogVGVzdFN0ZXBSZXN1bHRTdGF0dXMuU0tJUFBFRCxcbiAgICAgICAgICBkdXJhdGlvbjogVGltZUNvbnZlcnNpb24ubWlsbGlzZWNvbmRzVG9EdXJhdGlvbigwKSxcbiAgICAgICAgfSxcbiAgICAgIH1cbiAgICB9XG5cbiAgICBsZXQgc3RlcFJlc3VsdDogYW55XG4gICAgbGV0IGVycm9yOiBhbnlcbiAgICBsZXQgc3RlcFJlc3VsdHMgPSBhd2FpdCB0aGlzLnJ1blN0ZXBIb29rcyh0aGlzLmdldEJlZm9yZVN0ZXBIb29rRGVmaW5pdGlvbnMoKSwgcGlja2xlU3RlcClcbiAgICBpZiAoZ2V0V29yc3RUZXN0U3RlcFJlc3VsdChzdGVwUmVzdWx0cykuc3RhdHVzICE9PSBUZXN0U3RlcFJlc3VsdFN0YXR1cy5GQUlMRUQpIHtcbiAgICAgIHN0ZXBSZXN1bHQgPSBhd2FpdCB0aGlzLmludm9rZVN0ZXAocGlja2xlU3RlcCwgc3RlcERlZmluaXRpb25zWzBdKVxuICAgICAgc3RlcFJlc3VsdHMucHVzaChzdGVwUmVzdWx0LnJlc3VsdClcbiAgICAgIGVycm9yID0gc3RlcFJlc3VsdC5lcnJvclxuICAgIH1cbiAgICBjb25zdCBhZnRlclN0ZXBIb29rUmVzdWx0cyA9IGF3YWl0IHRoaXMucnVuU3RlcEhvb2tzKFxuICAgICAgdGhpcy5nZXRBZnRlclN0ZXBIb29rRGVmaW5pdGlvbnMoKSxcbiAgICAgIHBpY2tsZVN0ZXAsXG4gICAgICBzdGVwUmVzdWx0XG4gICAgKVxuICAgIHN0ZXBSZXN1bHRzID0gc3RlcFJlc3VsdHMuY29uY2F0KGFmdGVyU3RlcEhvb2tSZXN1bHRzKVxuXG4gICAgY29uc3QgZmluYWxTdGVwUmVzdWx0ID0gZ2V0V29yc3RUZXN0U3RlcFJlc3VsdChzdGVwUmVzdWx0cylcbiAgICBsZXQgZmluYWxEdXJhdGlvbiA9IFRpbWVDb252ZXJzaW9uLm1pbGxpc2Vjb25kc1RvRHVyYXRpb24oMClcbiAgICBmb3IgKGNvbnN0IHJlc3VsdCBvZiBzdGVwUmVzdWx0cykge1xuICAgICAgZmluYWxEdXJhdGlvbiA9IFRpbWVDb252ZXJzaW9uLmFkZER1cmF0aW9ucyhmaW5hbER1cmF0aW9uLCByZXN1bHQuZHVyYXRpb24pXG4gICAgfVxuICAgIGZpbmFsU3RlcFJlc3VsdC5kdXJhdGlvbiA9IGZpbmFsRHVyYXRpb25cbiAgICByZXR1cm4ge1xuICAgICAgcmVzdWx0OiBmaW5hbFN0ZXBSZXN1bHQsXG4gICAgICBlcnJvcixcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gZmluZEhvb2tEZWZpbml0aW9uKFxuICBpZDogc3RyaW5nLFxuICBzdXBwb3J0Q29kZUxpYnJhcnk6IFN1cHBvcnRDb2RlTGlicmFyeVxuKTogVGVzdENhc2VIb29rRGVmaW5pdGlvbiB7XG4gIHJldHVybiBbXG4gICAgLi4uc3VwcG9ydENvZGVMaWJyYXJ5LmJlZm9yZVRlc3RDYXNlSG9va0RlZmluaXRpb25zLFxuICAgIC4uLnN1cHBvcnRDb2RlTGlicmFyeS5hZnRlclRlc3RDYXNlSG9va0RlZmluaXRpb25zLFxuICBdLmZpbmQoKGRlZmluaXRpb24pID0+IGRlZmluaXRpb24uaWQgPT09IGlkKVxufVxuXG5mdW5jdGlvbiBmaW5kU3RlcERlZmluaXRpb24oaWQ6IHN0cmluZywgc3VwcG9ydENvZGVMaWJyYXJ5OiBTdXBwb3J0Q29kZUxpYnJhcnkpOiBTdGVwRGVmaW5pdGlvbiB7XG4gIHJldHVybiBzdXBwb3J0Q29kZUxpYnJhcnkuc3RlcERlZmluaXRpb25zLmZpbmQoKGRlZmluaXRpb24pID0+IGRlZmluaXRpb24uaWQgPT09IGlkKVxufVxuIl19