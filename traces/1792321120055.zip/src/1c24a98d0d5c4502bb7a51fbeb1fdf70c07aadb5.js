"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Worker = void 0;
const messages_1 = require("@cucumber/messages");
const user_code_runner_1 = __importDefault(require("../user_code_runner"));
const value_checker_1 = require("../value_checker");
const format_error_1 = require("./format_error");
const helpers_1 = require("./helpers");
const scope_1 = require("./scope");
const stopwatch_1 = require("./stopwatch");
const test_case_runner_1 = __importDefault(require("./test_case_runner"));
/**
 * Runs individual units of work asynchronously
 * @remarks
 * Unaware of the overall test run scope, or whether it's on the main thread,
 * or whether any other workers are in play.
 */
class Worker {
    testRunStartedId;
    workerId;
    eventBroadcaster;
    newId;
    options;
    supportCodeLibrary;
    snippetBuilder;
    constructor(testRunStartedId, workerId, eventBroadcaster, newId, options, supportCodeLibrary, snippetBuilder) {
        this.testRunStartedId = testRunStartedId;
        this.workerId = workerId;
        this.eventBroadcaster = eventBroadcaster;
        this.newId = newId;
        this.options = options;
        this.supportCodeLibrary = supportCodeLibrary;
        this.snippetBuilder = snippetBuilder;
    }
    async runTestRunHook(hookDefinition) {
        const testRunHookStartedId = this.newId();
        this.eventBroadcaster.emit('envelope', {
            testRunHookStarted: {
                testRunStartedId: this.testRunStartedId,
                workerId: this.workerId,
                id: testRunHookStartedId,
                hookId: hookDefinition.id,
                timestamp: (0, stopwatch_1.timestamp)(),
            },
        });
        let result;
        if (this.options.dryRun) {
            result = {
                duration: {
                    seconds: 0,
                    nanos: 0,
                },
                status: messages_1.TestStepResultStatus.SKIPPED,
            };
        }
        else {
            const stopwatch = (0, stopwatch_1.create)().start();
            const context = { parameters: this.options.worldParameters };
            const { error } = await (0, scope_1.runInTestRunScope)({ context }, () => user_code_runner_1.default.run({
                argsArray: [],
                fn: hookDefinition.code,
                thisArg: context,
                timeoutInMilliseconds: (0, value_checker_1.valueOrDefault)(hookDefinition.options.timeout, this.supportCodeLibrary.defaultTimeout),
            }));
            const duration = stopwatch.stop().duration();
            if ((0, value_checker_1.doesHaveValue)(error)) {
                result = {
                    duration,
                    status: messages_1.TestStepResultStatus.FAILED,
                    ...(0, format_error_1.formatError)(error, this.options.filterStacktraces),
                };
            }
            else {
                result = {
                    duration,
                    status: messages_1.TestStepResultStatus.PASSED,
                };
            }
        }
        this.eventBroadcaster.emit('envelope', {
            testRunHookFinished: {
                testRunHookStartedId,
                result,
                timestamp: (0, stopwatch_1.timestamp)(),
            },
        });
        return result.status !== messages_1.TestStepResultStatus.FAILED;
    }
    async runBeforeAllHooks() {
        let success = true;
        for (const hookDefinition of this.supportCodeLibrary.beforeTestRunHookDefinitions) {
            if (!(await this.runTestRunHook(hookDefinition))) {
                success = false;
            }
        }
        return success;
    }
    async runTestCase({ gherkinDocument, pickle, testCase }, failing) {
        const testCaseRunner = new test_case_runner_1.default({
            workerId: this.workerId,
            eventBroadcaster: this.eventBroadcaster,
            newId: this.newId,
            gherkinDocument,
            pickle,
            testCase,
            retries: (0, helpers_1.retriesForPickle)(pickle, this.options),
            skip: this.options.dryRun || (this.options.failFast && failing),
            filterStackTraces: this.options.filterStacktraces,
            supportCodeLibrary: this.supportCodeLibrary,
            worldParameters: this.options.worldParameters,
            snippetBuilder: this.snippetBuilder,
        });
        const status = await testCaseRunner.run();
        return !(0, helpers_1.shouldCauseFailure)(status, this.options);
    }
    async runAfterAllHooks() {
        let success = true;
        const reversed = [...this.supportCodeLibrary.afterTestRunHookDefinitions].reverse();
        for (const hookDefinition of reversed) {
            if (!(await this.runTestRunHook(hookDefinition))) {
                success = false;
            }
        }
        return success;
    }
}
exports.Worker = Worker;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid29ya2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3J1bnRpbWUvd29ya2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztBQUNBLGlEQUsyQjtBQUszQiwyRUFBZ0Q7QUFDaEQsb0RBQWdFO0FBQ2hFLGlEQUE0QztBQUM1Qyx1Q0FBZ0U7QUFDaEUsbUNBQTJDO0FBQzNDLDJDQUErQztBQUMvQywwRUFBK0M7QUFHL0M7Ozs7O0dBS0c7QUFDSCxNQUFhLE1BQU07SUFFRTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQVBuQixZQUNtQixnQkFBd0IsRUFDeEIsUUFBNEIsRUFDNUIsZ0JBQThCLEVBQzlCLEtBQXdCLEVBQ3hCLE9BQXVCLEVBQ3ZCLGtCQUFzQyxFQUN0QyxjQUE0QztRQU41QyxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQVE7UUFDeEIsYUFBUSxHQUFSLFFBQVEsQ0FBb0I7UUFDNUIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFjO1FBQzlCLFVBQUssR0FBTCxLQUFLLENBQW1CO1FBQ3hCLFlBQU8sR0FBUCxPQUFPLENBQWdCO1FBQ3ZCLHVCQUFrQixHQUFsQixrQkFBa0IsQ0FBb0I7UUFDdEMsbUJBQWMsR0FBZCxjQUFjLENBQThCO0lBQzVELENBQUM7SUFFSSxLQUFLLENBQUMsY0FBYyxDQUFDLGNBQXFDO1FBQ2hFLE1BQU0sb0JBQW9CLEdBQUcsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFBO1FBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ3JDLGtCQUFrQixFQUFFO2dCQUNsQixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO2dCQUN2QyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7Z0JBQ3ZCLEVBQUUsRUFBRSxvQkFBb0I7Z0JBQ3hCLE1BQU0sRUFBRSxjQUFjLENBQUMsRUFBRTtnQkFDekIsU0FBUyxFQUFFLElBQUEscUJBQVMsR0FBRTthQUN2QjtTQUNpQixDQUFDLENBQUE7UUFFckIsSUFBSSxNQUFzQixDQUFBO1FBQzFCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN4QixNQUFNLEdBQUc7Z0JBQ1AsUUFBUSxFQUFFO29CQUNSLE9BQU8sRUFBRSxDQUFDO29CQUNWLEtBQUssRUFBRSxDQUFDO2lCQUNUO2dCQUNELE1BQU0sRUFBRSwrQkFBb0IsQ0FBQyxPQUFPO2FBQ3JDLENBQUE7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sU0FBUyxHQUFHLElBQUEsa0JBQU0sR0FBRSxDQUFDLEtBQUssRUFBRSxDQUFBO1lBQ2xDLE1BQU0sT0FBTyxHQUFHLEVBQUUsVUFBVSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxFQUFFLENBQUE7WUFDNUQsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sSUFBQSx5QkFBaUIsRUFBQyxFQUFFLE9BQU8sRUFBRSxFQUFFLEdBQUcsRUFBRSxDQUMxRCwwQkFBYyxDQUFDLEdBQUcsQ0FBQztnQkFDakIsU0FBUyxFQUFFLEVBQUU7Z0JBQ2IsRUFBRSxFQUFFLGNBQWMsQ0FBQyxJQUFJO2dCQUN2QixPQUFPLEVBQUUsT0FBTztnQkFDaEIscUJBQXFCLEVBQUUsSUFBQSw4QkFBYyxFQUNuQyxjQUFjLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFDOUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGNBQWMsQ0FDdkM7YUFDRixDQUFDLENBQ0gsQ0FBQTtZQUNELE1BQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQTtZQUU1QyxJQUFJLElBQUEsNkJBQWEsRUFBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN6QixNQUFNLEdBQUc7b0JBQ1AsUUFBUTtvQkFDUixNQUFNLEVBQUUsK0JBQW9CLENBQUMsTUFBTTtvQkFDbkMsR0FBRyxJQUFBLDBCQUFXLEVBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUM7aUJBQ3RELENBQUE7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxHQUFHO29CQUNQLFFBQVE7b0JBQ1IsTUFBTSxFQUFFLCtCQUFvQixDQUFDLE1BQU07aUJBQ3BDLENBQUE7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFO1lBQ3JDLG1CQUFtQixFQUFFO2dCQUNuQixvQkFBb0I7Z0JBQ3BCLE1BQU07Z0JBQ04sU0FBUyxFQUFFLElBQUEscUJBQVMsR0FBRTthQUN2QjtTQUNpQixDQUFDLENBQUE7UUFFckIsT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLCtCQUFvQixDQUFDLE1BQU0sQ0FBQTtJQUN0RCxDQUFDO0lBRUQsS0FBSyxDQUFDLGlCQUFpQjtRQUNyQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUE7UUFDbEIsS0FBSyxNQUFNLGNBQWMsSUFBSSxJQUFJLENBQUMsa0JBQWtCLENBQUMsNEJBQTRCLEVBQUUsQ0FBQztZQUNsRixJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNqRCxPQUFPLEdBQUcsS0FBSyxDQUFBO1lBQ2pCLENBQUM7UUFDSCxDQUFDO1FBQ0QsT0FBTyxPQUFPLENBQUE7SUFDaEIsQ0FBQztJQUVELEtBQUssQ0FBQyxXQUFXLENBQ2YsRUFBRSxlQUFlLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBcUIsRUFDeEQsT0FBZ0I7UUFFaEIsTUFBTSxjQUFjLEdBQUcsSUFBSSwwQkFBYyxDQUFDO1lBQ3hDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtZQUN2QixnQkFBZ0IsRUFBRSxJQUFJLENBQUMsZ0JBQWdCO1lBQ3ZDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixlQUFlO1lBQ2YsTUFBTTtZQUNOLFFBQVE7WUFDUixPQUFPLEVBQUUsSUFBQSwwQkFBZ0IsRUFBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUMvQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsSUFBSSxPQUFPLENBQUM7WUFDL0QsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUI7WUFDakQsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLGtCQUFrQjtZQUMzQyxlQUFlLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlO1lBQzdDLGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYztTQUNwQyxDQUFDLENBQUE7UUFFRixNQUFNLE1BQU0sR0FBRyxNQUFNLGNBQWMsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtRQUV6QyxPQUFPLENBQUMsSUFBQSw0QkFBa0IsRUFBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ2xELENBQUM7SUFFRCxLQUFLLENBQUMsZ0JBQWdCO1FBQ3BCLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQTtRQUNsQixNQUFNLFFBQVEsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLDJCQUEyQixDQUFDLENBQUMsT0FBTyxFQUFFLENBQUE7UUFDbkYsS0FBSyxNQUFNLGNBQWMsSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUN0QyxJQUFJLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNqRCxPQUFPLEdBQUcsS0FBSyxDQUFBO1lBQ2pCLENBQUM7UUFDSCxDQUFDO1FBQ0QsT0FBTyxPQUFPLENBQUE7SUFDaEIsQ0FBQztDQUNGO0FBckhELHdCQXFIQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgRXZlbnRFbWl0dGVyIH0gZnJvbSAnbm9kZTpldmVudHMnXG5pbXBvcnQge1xuICB0eXBlIEVudmVsb3BlLFxuICB0eXBlIElkR2VuZXJhdG9yLFxuICB0eXBlIFRlc3RTdGVwUmVzdWx0LFxuICBUZXN0U3RlcFJlc3VsdFN0YXR1cyxcbn0gZnJvbSAnQGN1Y3VtYmVyL21lc3NhZ2VzJ1xuaW1wb3J0IHR5cGUgeyBBc3NlbWJsZWRUZXN0Q2FzZSB9IGZyb20gJy4uL2Fzc2VtYmxlJ1xuaW1wb3J0IHR5cGUgU3RlcERlZmluaXRpb25TbmlwcGV0QnVpbGRlciBmcm9tICcuLi9mb3JtYXR0ZXIvc3RlcF9kZWZpbml0aW9uX3NuaXBwZXRfYnVpbGRlcidcbmltcG9ydCB0eXBlIFRlc3RSdW5Ib29rRGVmaW5pdGlvbiBmcm9tICcuLi9tb2RlbHMvdGVzdF9ydW5faG9va19kZWZpbml0aW9uJ1xuaW1wb3J0IHR5cGUgeyBTdXBwb3J0Q29kZUxpYnJhcnkgfSBmcm9tICcuLi9zdXBwb3J0X2NvZGVfbGlicmFyeV9idWlsZGVyL3R5cGVzJ1xuaW1wb3J0IFVzZXJDb2RlUnVubmVyIGZyb20gJy4uL3VzZXJfY29kZV9ydW5uZXInXG5pbXBvcnQgeyBkb2VzSGF2ZVZhbHVlLCB2YWx1ZU9yRGVmYXVsdCB9IGZyb20gJy4uL3ZhbHVlX2NoZWNrZXInXG5pbXBvcnQgeyBmb3JtYXRFcnJvciB9IGZyb20gJy4vZm9ybWF0X2Vycm9yJ1xuaW1wb3J0IHsgcmV0cmllc0ZvclBpY2tsZSwgc2hvdWxkQ2F1c2VGYWlsdXJlIH0gZnJvbSAnLi9oZWxwZXJzJ1xuaW1wb3J0IHsgcnVuSW5UZXN0UnVuU2NvcGUgfSBmcm9tICcuL3Njb3BlJ1xuaW1wb3J0IHsgY3JlYXRlLCB0aW1lc3RhbXAgfSBmcm9tICcuL3N0b3B3YXRjaCdcbmltcG9ydCBUZXN0Q2FzZVJ1bm5lciBmcm9tICcuL3Rlc3RfY2FzZV9ydW5uZXInXG5pbXBvcnQgdHlwZSB7IFJ1bnRpbWVPcHRpb25zIH0gZnJvbSAnLi90eXBlcydcblxuLyoqXG4gKiBSdW5zIGluZGl2aWR1YWwgdW5pdHMgb2Ygd29yayBhc3luY2hyb25vdXNseVxuICogQHJlbWFya3NcbiAqIFVuYXdhcmUgb2YgdGhlIG92ZXJhbGwgdGVzdCBydW4gc2NvcGUsIG9yIHdoZXRoZXIgaXQncyBvbiB0aGUgbWFpbiB0aHJlYWQsXG4gKiBvciB3aGV0aGVyIGFueSBvdGhlciB3b3JrZXJzIGFyZSBpbiBwbGF5LlxuICovXG5leHBvcnQgY2xhc3MgV29ya2VyIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByZWFkb25seSB0ZXN0UnVuU3RhcnRlZElkOiBzdHJpbmcsXG4gICAgcHJpdmF0ZSByZWFkb25seSB3b3JrZXJJZDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgZXZlbnRCcm9hZGNhc3RlcjogRXZlbnRFbWl0dGVyLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgbmV3SWQ6IElkR2VuZXJhdG9yLk5ld0lkLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgb3B0aW9uczogUnVudGltZU9wdGlvbnMsXG4gICAgcHJpdmF0ZSByZWFkb25seSBzdXBwb3J0Q29kZUxpYnJhcnk6IFN1cHBvcnRDb2RlTGlicmFyeSxcbiAgICBwcml2YXRlIHJlYWRvbmx5IHNuaXBwZXRCdWlsZGVyOiBTdGVwRGVmaW5pdGlvblNuaXBwZXRCdWlsZGVyXG4gICkge31cblxuICBwcml2YXRlIGFzeW5jIHJ1blRlc3RSdW5Ib29rKGhvb2tEZWZpbml0aW9uOiBUZXN0UnVuSG9va0RlZmluaXRpb24pOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBjb25zdCB0ZXN0UnVuSG9va1N0YXJ0ZWRJZCA9IHRoaXMubmV3SWQoKVxuICAgIHRoaXMuZXZlbnRCcm9hZGNhc3Rlci5lbWl0KCdlbnZlbG9wZScsIHtcbiAgICAgIHRlc3RSdW5Ib29rU3RhcnRlZDoge1xuICAgICAgICB0ZXN0UnVuU3RhcnRlZElkOiB0aGlzLnRlc3RSdW5TdGFydGVkSWQsXG4gICAgICAgIHdvcmtlcklkOiB0aGlzLndvcmtlcklkLFxuICAgICAgICBpZDogdGVzdFJ1bkhvb2tTdGFydGVkSWQsXG4gICAgICAgIGhvb2tJZDogaG9va0RlZmluaXRpb24uaWQsXG4gICAgICAgIHRpbWVzdGFtcDogdGltZXN0YW1wKCksXG4gICAgICB9LFxuICAgIH0gc2F0aXNmaWVzIEVudmVsb3BlKVxuXG4gICAgbGV0IHJlc3VsdDogVGVzdFN0ZXBSZXN1bHRcbiAgICBpZiAodGhpcy5vcHRpb25zLmRyeVJ1bikge1xuICAgICAgcmVzdWx0ID0ge1xuICAgICAgICBkdXJhdGlvbjoge1xuICAgICAgICAgIHNlY29uZHM6IDAsXG4gICAgICAgICAgbmFub3M6IDAsXG4gICAgICAgIH0sXG4gICAgICAgIHN0YXR1czogVGVzdFN0ZXBSZXN1bHRTdGF0dXMuU0tJUFBFRCxcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgc3RvcHdhdGNoID0gY3JlYXRlKCkuc3RhcnQoKVxuICAgICAgY29uc3QgY29udGV4dCA9IHsgcGFyYW1ldGVyczogdGhpcy5vcHRpb25zLndvcmxkUGFyYW1ldGVycyB9XG4gICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBydW5JblRlc3RSdW5TY29wZSh7IGNvbnRleHQgfSwgKCkgPT5cbiAgICAgICAgVXNlckNvZGVSdW5uZXIucnVuKHtcbiAgICAgICAgICBhcmdzQXJyYXk6IFtdLFxuICAgICAgICAgIGZuOiBob29rRGVmaW5pdGlvbi5jb2RlLFxuICAgICAgICAgIHRoaXNBcmc6IGNvbnRleHQsXG4gICAgICAgICAgdGltZW91dEluTWlsbGlzZWNvbmRzOiB2YWx1ZU9yRGVmYXVsdChcbiAgICAgICAgICAgIGhvb2tEZWZpbml0aW9uLm9wdGlvbnMudGltZW91dCxcbiAgICAgICAgICAgIHRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5LmRlZmF1bHRUaW1lb3V0XG4gICAgICAgICAgKSxcbiAgICAgICAgfSlcbiAgICAgIClcbiAgICAgIGNvbnN0IGR1cmF0aW9uID0gc3RvcHdhdGNoLnN0b3AoKS5kdXJhdGlvbigpXG5cbiAgICAgIGlmIChkb2VzSGF2ZVZhbHVlKGVycm9yKSkge1xuICAgICAgICByZXN1bHQgPSB7XG4gICAgICAgICAgZHVyYXRpb24sXG4gICAgICAgICAgc3RhdHVzOiBUZXN0U3RlcFJlc3VsdFN0YXR1cy5GQUlMRUQsXG4gICAgICAgICAgLi4uZm9ybWF0RXJyb3IoZXJyb3IsIHRoaXMub3B0aW9ucy5maWx0ZXJTdGFja3RyYWNlcyksXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdCA9IHtcbiAgICAgICAgICBkdXJhdGlvbixcbiAgICAgICAgICBzdGF0dXM6IFRlc3RTdGVwUmVzdWx0U3RhdHVzLlBBU1NFRCxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMuZXZlbnRCcm9hZGNhc3Rlci5lbWl0KCdlbnZlbG9wZScsIHtcbiAgICAgIHRlc3RSdW5Ib29rRmluaXNoZWQ6IHtcbiAgICAgICAgdGVzdFJ1bkhvb2tTdGFydGVkSWQsXG4gICAgICAgIHJlc3VsdCxcbiAgICAgICAgdGltZXN0YW1wOiB0aW1lc3RhbXAoKSxcbiAgICAgIH0sXG4gICAgfSBzYXRpc2ZpZXMgRW52ZWxvcGUpXG5cbiAgICByZXR1cm4gcmVzdWx0LnN0YXR1cyAhPT0gVGVzdFN0ZXBSZXN1bHRTdGF0dXMuRkFJTEVEXG4gIH1cblxuICBhc3luYyBydW5CZWZvcmVBbGxIb29rcygpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBsZXQgc3VjY2VzcyA9IHRydWVcbiAgICBmb3IgKGNvbnN0IGhvb2tEZWZpbml0aW9uIG9mIHRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5LmJlZm9yZVRlc3RSdW5Ib29rRGVmaW5pdGlvbnMpIHtcbiAgICAgIGlmICghKGF3YWl0IHRoaXMucnVuVGVzdFJ1bkhvb2soaG9va0RlZmluaXRpb24pKSkge1xuICAgICAgICBzdWNjZXNzID0gZmFsc2VcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHN1Y2Nlc3NcbiAgfVxuXG4gIGFzeW5jIHJ1blRlc3RDYXNlKFxuICAgIHsgZ2hlcmtpbkRvY3VtZW50LCBwaWNrbGUsIHRlc3RDYXNlIH06IEFzc2VtYmxlZFRlc3RDYXNlLFxuICAgIGZhaWxpbmc6IGJvb2xlYW5cbiAgKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgY29uc3QgdGVzdENhc2VSdW5uZXIgPSBuZXcgVGVzdENhc2VSdW5uZXIoe1xuICAgICAgd29ya2VySWQ6IHRoaXMud29ya2VySWQsXG4gICAgICBldmVudEJyb2FkY2FzdGVyOiB0aGlzLmV2ZW50QnJvYWRjYXN0ZXIsXG4gICAgICBuZXdJZDogdGhpcy5uZXdJZCxcbiAgICAgIGdoZXJraW5Eb2N1bWVudCxcbiAgICAgIHBpY2tsZSxcbiAgICAgIHRlc3RDYXNlLFxuICAgICAgcmV0cmllczogcmV0cmllc0ZvclBpY2tsZShwaWNrbGUsIHRoaXMub3B0aW9ucyksXG4gICAgICBza2lwOiB0aGlzLm9wdGlvbnMuZHJ5UnVuIHx8ICh0aGlzLm9wdGlvbnMuZmFpbEZhc3QgJiYgZmFpbGluZyksXG4gICAgICBmaWx0ZXJTdGFja1RyYWNlczogdGhpcy5vcHRpb25zLmZpbHRlclN0YWNrdHJhY2VzLFxuICAgICAgc3VwcG9ydENvZGVMaWJyYXJ5OiB0aGlzLnN1cHBvcnRDb2RlTGlicmFyeSxcbiAgICAgIHdvcmxkUGFyYW1ldGVyczogdGhpcy5vcHRpb25zLndvcmxkUGFyYW1ldGVycyxcbiAgICAgIHNuaXBwZXRCdWlsZGVyOiB0aGlzLnNuaXBwZXRCdWlsZGVyLFxuICAgIH0pXG5cbiAgICBjb25zdCBzdGF0dXMgPSBhd2FpdCB0ZXN0Q2FzZVJ1bm5lci5ydW4oKVxuXG4gICAgcmV0dXJuICFzaG91bGRDYXVzZUZhaWx1cmUoc3RhdHVzLCB0aGlzLm9wdGlvbnMpXG4gIH1cblxuICBhc3luYyBydW5BZnRlckFsbEhvb2tzKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGxldCBzdWNjZXNzID0gdHJ1ZVxuICAgIGNvbnN0IHJldmVyc2VkID0gWy4uLnRoaXMuc3VwcG9ydENvZGVMaWJyYXJ5LmFmdGVyVGVzdFJ1bkhvb2tEZWZpbml0aW9uc10ucmV2ZXJzZSgpXG4gICAgZm9yIChjb25zdCBob29rRGVmaW5pdGlvbiBvZiByZXZlcnNlZCkge1xuICAgICAgaWYgKCEoYXdhaXQgdGhpcy5ydW5UZXN0UnVuSG9vayhob29rRGVmaW5pdGlvbikpKSB7XG4gICAgICAgIHN1Y2Nlc3MgPSBmYWxzZVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc3VjY2Vzc1xuICB9XG59XG4iXX0=